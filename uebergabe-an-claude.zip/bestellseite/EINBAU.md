<!--
  BESTELLSEITE MIT PRODUKTKACHELN, Stand 23.10.2026
  FERTIG: index.html und bestellen.js der echten Bestellseite mit drei wählbaren Produktkacheln (K8, ANESPA DX, emGuarde Go), heller Kopf.
  FEHLT:  Schweizer Preise für emGuarde und ANESPA DX, Genehmigung Enagic für Bilder mit Enagic-Logo, Telegram-Zeile (SQL unten).
-->

# Einbau: Bestellseite mit Produktkacheln

Für den Claude mit Zugriff auf Server und Datenbank. Grundlage war `von-hauptsystem/website/bestellen/`
aus dem Repository VIP-Group-Business (Stand 23.10.2026).

## 1. Dateien ersetzen

- `website/bestellen/index.html` ersetzen durch `fertig/website/bestellen/index.html`
- `website/bestellen/bestellen.js` ersetzen durch `fertig/website/bestellen/bestellen.js`
- **Wichtig:** In `bestellen.js` steht der Supabase-Schlüssel als `XXX`. Vor dem Hochladen den echten
  öffentlichen Schlüssel wieder eintragen (Zeile mit `supabase.createClient`).

Die Ordner `bilder/`, `dashboard/`, `vendor/` in `fertig/website/` sind nur zum Testen dabei, dort ändert sich nichts.

## 2. Was sich geändert hat

- Der Block „Dein Gerät“ ist jetzt „Was möchtest du bestellen?“ mit drei Kacheln:
  LeveLuk K8, ANESPA DX, emGuarde Go. Klick auf ein Bild öffnet ein Fenster mit Infos.
  Jede Kachel hat unten „Auswählen“. Der K8 ist vorausgewählt, lässt sich aber abwählen
  (zum Beispiel wenn jemand nur emGuarde bestellt). Mindestens ein Produkt muss gewählt sein.
- **Neu, wichtig fürs Dashboard:** In `daten` steht jetzt `k8` mit `"ja"` oder `"nein"`.
  Bei `"nein"` kein K8-Formular für Enagic ausfüllen. Ältere Bestellungen ohne das Feld sind K8-Bestellungen.
  Ohne K8 zeigt der Block „Bezahlung“ keinen K8-Preis, sondern: Preis und Bezahlung klären wir persönlich.
- **Land zuerst:** Oben steht „Wo wohnst du?“ mit Flaggen. Erst nach der Wahl erscheint der Rest der Seite.
  Reihenfolge: bei `?von=daniel` Schweiz, Deutschland, Österreich, sonst Deutschland, Schweiz, Österreich,
  dazu „Anderes Land“ mit Auswahlliste. Die Wahl setzt das vorhandene Feld `land_kurz`, es kommt kein neues Feld dazu.
  Für Österreich und andere Länder gibt es noch keine Preise (Fragen D22 bis D24), dort steht „Preis persönlich“.
- Text „Wie möchtest du kaufen?“ erklärt jetzt Kunde und Vertriebspartner (Distributor). Die Werte bleiben `Verbraucher` und `Distributor`.
- Kopf der Seite jetzt hell (statt dunkelgrün), Logo `logo-oliv.png`. Auswahlfelder (Kaufart, Bezahlung,
  Haken) sind eigene Kreise und Kästchen: leer = weiß, gewählt = Oliv.
- Die Haken heißen `zusatz_emguarde` und `zusatz_anespa`. Sie stehen im Formular, landen also ohne
  weitere Änderung in `daten` (jsonb) in `uk_bestellungen`, Wert `"on"` wenn gewählt.
- Die Preise in den Kacheln wechseln mit dem Land. Für die Schweiz steht bei den Ergänzungen
  „Preis nennen wir dir persönlich“.
- Ist eine Ergänzung gewählt, steht unter dem Preis im Block „Bezahlung“, dass Preis und Bezahlung
  dafür persönlich geklärt werden.
- Produktdaten und Preise stehen oben im Abschnitt `PRODUKTE` in `bestellen.js` (Preise ohne MwSt.
  laut Enagic-Shop, Stand 23.10.2026).
- Die abweichende Lieferadresse gab es schon (`liefer_anders`, `liefer_name`, `liefer_adresse`),
  daran ist nichts geändert.

## 3. Telegram-Nachricht ergänzen (Datenbank)

In der Funktion `uk_bestellung_melden()` eine Zeile anhängen, wenn Ergänzungen gewählt sind, sinngemäß:

```sql
-- im Aufbau des Nachrichtentexts:
|| case when (new.daten->>'k8') = 'nein' then E'\nOHNE K8, nur Ergänzungen' else '' end
|| case when (new.daten->>'zusatz_emguarde') = 'on' or (new.daten->>'zusatz_anespa') = 'on'
     then E'\nDazu gewünscht: ' || concat_ws(', ',
       case when (new.daten->>'zusatz_emguarde') = 'on' then 'emGuarde Go' end,
       case when (new.daten->>'zusatz_anespa') = 'on' then 'ANESPA DX' end)
     else '' end
```

Gern auch im Dashboard unter Bestellungen anzeigen.

## 4. Nicht automatisch an Enagic

emGuarde und ANESPA DX gehen nicht in das K8-Bestellformular. Bei `k8 = "nein"` gibt es gar kein K8-Formular. Daniel klärt Preis, Zahlung und
Bestellung mit dem Kunden selbst. Die Bestätigungsmail an den Kunden (`mail-senden`) kann einen Satz bekommen:
„Zu deinen gewünschten Ergänzungen melden wir uns persönlich bei dir.“

## 5. Noch offen

- Schweizer Preise für emGuarde und ANESPA DX
- Die Produktbilder (bilder/k8.jpg, anespa.jpg, emguarde.jpg) sind KI-Bilder, zeigen aber das Enagic-Logo. Genehmigung klären (Frage D7). Ordner `bilder/` mit hochladen.
- emGuarde laut Shop nur bei Vorauszahlung, obwohl „10 Zahlungen“ angezeigt wird: mit Daniel klären.
