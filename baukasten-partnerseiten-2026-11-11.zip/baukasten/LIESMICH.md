# Baukasten Partnerseiten (Paket "Eigene Seite")

Stand 11.11.2026. Für Jasmin und den Claude mit Zugang zu Datenbank und Server.
Nichts davon ist hochgeladen oder eingespielt. Alle Schlüssel stehen als `XXX` drin.

## Worum es geht

Jeder Partner bekommt eigene Empfehlungsseiten mit E-Book, ohne dass jemand von Hand baut oder hochlädt.

- **Drei feste Seiten** für alle Partner: `website/p/neutral.html`, `sport.html`, `gesundheit.html`. Dazu die
  neutrale Startseite `start.html` für `wasseristmehr.com` (Abschnitt unten).
- Die Adresse sagt, wer es ist: **`wasseristmehr.com/max-muster`** (Jasmin, 12.11.2026: einfach Domain und Name,
  "nicht Sport oder irgendwas"). Der kurze Link zeigt die **Hauptseite** des Partners. Hat er mehrere Fassungen, wählt
  er im Portal, welche das ist (Standard: die erste in der Reihe Neutral, Sport, Gesundheit). Die anderen erreicht man
  über `wasseristmehr.com/max-muster/sport`. Die alte Form `/p/max-muster/sport` geht weiterhin (auch auf
  mein.ursprungskraft.net), auf wasseristmehr.com schreibt die Seite sie selbst auf die kurze Form um.
  Netlify leitet per `_redirects` auf die feste Seite um (eine Zeile je Fassung). Bei `/max-muster` liefert Netlify immer
  `neutral.html`. Ist die Hauptseite eine andere, lädt die Seite die richtige Datei nach, der Link bleibt kurz.
  Die Seite holt Name, Foto, Rolle, Satz und Instagram über die öffentliche Funktion
  `uk_seite_oeffentlich()`. Telefon und E-Mail des Partners nur, wenn er es im Formular ausdrücklich freigibt.
- **Kein Upload je Partner.** Ein neuer Partner ist nur eine Zeile in der Datenbank.
- **Leads** gehen wie bei Kevin und Johny an die Edge Function `partner-lead`, mit `von` = Kürzel des Partners
  (`uk_partner.kurz`). Die Adresse der Seite darf sich ändern, das Kürzel nie. So bleibt jeder Lead für immer beim
  Partner, über den er kam. Zusätzlich gespeichert: `antworten.fassung` und `antworten.seite`.
- **E-Books:** eine Bibliothek mit 9 E-Books, je 3 zu Neutral, Sport und Gesundheit (Abschnitt unten). Jedes E-Book
  kommt im Look der passenden Seite des Partners, mit seinem Namen, Foto, Kontakt (mit Freigabe), Link und QR-Code.
- **Portal:** neue Ansicht "Meine Seiten". Nicht gebucht: lebendige Vorschau mit den Seiten von Daniel und Jasmin,
  Klick öffnet die Info-Seite. Gebucht: einmal das Formular, danach je Fassung "Link kopieren", "Vorschau" und E-Book.
- **Anmeldung** im Portal wie bisher mit Sitzungsschlüssel (`uk_partner_konten`, `uk_partner_sitzungen`),
  nicht über Supabase Auth (Grund oben in `umbau-2026-11-11-backoffice-sportler.sql`).
- **Bezahlen:** nur die Schnittstelle (`uk_partner_seiten_paket.gebucht_bis`). Stripe baut ihr.
- **Basis-Adresse:** die neutrale Domain **wasseristmehr.com** (gesichert am 12.11.2026). Steht an **einer** Stelle:
  `uk_einstellungen`, Name `seiten_basis`.
  Portal und E-Book lesen sie dort. Die Seiten selbst laufen unter jeder Domain. Domain wechseln heißt also:
  Domain in Netlify dazunehmen, einen Wert in der Datenbank ändern, **kein** Upload.

## Startseite wasseristmehr.com (Jasmin, 12.11.2026)

Wer nur `wasseristmehr.com` aufruft, sieht eine neutrale Seite **ohne Person**: oben "Wasser ist mehr", darüber
"Wasser, das unterschätzte Supplement". Aufgebaut wie die neutrale Seite (Magazin, Hell, Oliv): fünf Wasserarten,
sechs Felder "Warum Wasser mehr ist" (Alltag, Training, Geschmack, Pflege, Haushalt, Kisten), Kisten-Rechner, Fragen,
Anfrage-Formular und E-Book. Datei: `website/p/start.html`.

- Technisch ist die Startseite ein Eintrag wie ein Partner: `uk_partner.kurz = 'wasseristmehr'`, `leads_bei = 'team'`,
  Paket bis 2099, Seite mit Adresse `wasseristmehr` (legt die SQL an, Abschnitt 8). Anfragen von dort landen also wie
  gewohnt in der Gruppe "Leads", mit Herkunft `wasseristmehr`. **Den Eintrag nicht löschen.**
- Das E-Book der Startseite spricht als "wir": "Ein E-Book von Wasser ist mehr", "Warum wir dir das empfehlen",
  unterschrieben mit "Dein Team von Wasser ist mehr". Der Text steht in `uk_partner_seiten.brief` dieses Eintrags.
  Beispiel: `website/p/vorschau/ebook-wasseristmehr.pdf`.
- Antwortet die Datenbank nicht, zeigt sich die Startseite trotzdem (Anfragen gehen dann ans Team).
- Sie steht noch auf `noindex` (Google zeigt sie nicht). Umstellen, wenn Impressum und Datenschutz für
  wasseristmehr.com fertig sind (`<meta name="robots">` in `start.html`).
- Für Partner gesperrte Adressen: alle Ordner der Website (`p`, `partner`, `dashboard`, `bestellen`, `impressum`,
  `datenschutz` ...) und `wasseristmehr`. Liste in `uk_seiten_adresse_reserviert`. Kommt ein neuer Ordner auf die
  Website, das Wort dort ergänzen.

## Wer kümmert sich um die Anfragen (Jasmin, 11.11.2026)

Daniel und Jasmin legen **je Partner** fest, wer sich bei den Interessenten meldet. Der Partner kann das nicht ändern.

| Einstellung | Wofür | Was passiert |
|---|---|---|
| **Daniel und Jasmin melden sich** (`team`, Standard) | Partner wie Kevin und Johny | Meldung in die Telegram-Gruppe "Leads" wie heute. Die Seite sagt "Wir melden uns bei dir". Der Partner sieht im Portal nur, wie viele Anfragen kamen. |
| **Partner kümmert sich selbst** (`partner`) | Partner, die ihre Leads selbst bearbeiten | Keine Meldung in die Gruppe "Leads". Die Seite sagt "Anna meldet sich bei dir". Der Partner sieht unter "Meine Seiten" jede Anfrage mit Telefon, E-Mail und Knöpfen zum Anrufen, WhatsApp und Mail. |

In beiden Fällen bleibt jede Anfrage für immer beim Partner, über dessen Seite sie kam.

**Anfragen-Bot für Partner, die sich selbst kümmern:** ein eigener Telegram-Bot nur für Anfragen, getrennt vom
Assistenten. Im Portal unter "Meine Seiten" steht der Knopf "Telegram verbinden". Ein Klick öffnet Telegram, der Partner
tippt auf "Starten", fertig. Ab dann kommt jede neue Anfrage sofort als Nachricht, mit Telefon, E-Mail und einem Knopf
"WhatsApp schreiben". Trennen geht im Portal oder im Bot mit /stop. Schreibt der Partner dem Bot etwas, antwortet er,
dass hier nur Anfragen ankommen und der Assistent für alles andere da ist.

**Einstellen:** im Dashboard, Reiter Partner, Partner anklicken, Feld "Anfragen über seine Seiten"
(Ergänzung in `dashboard-ergaenzung/app.js.diff`). Bis das eingespielt ist, im SQL-Editor:

```sql
update uk_partner set leads_bei = 'partner' where kurz = 'anna-beispiel';
```

Gespeichert in der neuen Spalte `uk_partner.leads_bei`. Heiße und warme Anfragen kommen in beiden Fällen wie bisher über
`uk_anfrage` in die Kundenliste, mit dem Kürzel des Partners (dadurch auch in seine Kundenübersicht im Portal).

## Farbwelten: Hell, Dunkel und Akzente (Jasmin, 12.11.2026)

Jede Seite gibt es in zwei Grundtönen und sieben Akzenten:

- **Dunkel:** Anthrazit wie bei Kevin und Johny.
- **Hell:** Creme und Beige, helle Felder mit feiner Kante.
- **Akzente:** Kupfer, Oliv, Salbei, Khaki, Petrol, Blau, Beere. Jeder Akzent ist auf Hell und auf Dunkel gut lesbar
  (Schrift mindestens 4,5 : 1, geprüft).

Der Partner wählt im Portal beim Einrichten unter der Vorschau, **für jede Seite einzeln**: Grundton anklicken, Akzent
anklicken, die Vorschau ändert sich sofort. Wählt er nichts, gilt der Vorschlag: Sport Dunkel und Kupfer, Neutral Hell
und Oliv, Gesundheit Hell und Salbei.

**Eine Stelle für alle Farben:** `website/p/farben.js`. Die Seiten, das Portal und später der Flyer-Editor lesen daraus
(`UKFarben.MODI`, `UKFarben.AKZENTE`, `UKFarben.anwenden(element, modus, akzent)`). Neuer Akzent: dort ergänzen und in
der SQL in `uk_seiten_akzente()`. Gespeichert wird die Wahl in `uk_partner_seiten.aussehen`.

**Aufbau (12.11.2026):** Dieselben Inhalte gibt es in drei Anordnungen, unabhängig von den Farben:

- **Felder:** wie Kevin und Johny, ein Mosaik aus runden Feldern. Das ist der Vorschlag für alle drei Seiten.
- **Magazin:** ruhig und mittig, große zentrierte Überschrift, darunter ein breites Bild, die Karten als Reihen mit Bild
  und Text im Wechsel, die Zahlen schlicht mit Haarlinien.
- **Bühne:** ein großes Foto über die ganze Breite mit dem Textfeld darauf, gerade Kanten, die Zahlen auf einem Band in
  der Akzentfarbe, die Karten als gleichmäßiges Raster ohne Abstand.

Die Wahl steht mit in `aussehen` (`"aufbau": "felder" | "magazin" | "buehne"`). Die Regeln stehen am Ende von
`website/p/seiten.css` (Abschnitt AUFBAU), die Namen in `farben.js` (`UKFarben.AUFBAU`). Kein zusätzliches HTML.

Ausprobieren: `http://localhost:8791/vorschau/farbwelten.html` (alle Kombinationen aus Aufbau, Grundton und Akzent,
Handy und Rechner nebeneinander).

## E-Book-Bibliothek (12.11.2026)

**Was der Partner bekommt:** alle 9 E-Books. Jede seiner Seiten bietet eins davon an (Vorschlag: das erste des Themas),
umstellen kann er das im Portal unter "Meine Seiten". Darunter steht die ganze Bibliothek mit "Ansehen" und "Link kopieren".

| Neutral | Sport | Gesundheit |
|---|---|---|
| Ein Gerät, fünf Wasserarten (Vorschlag) | Das unterschätzte Supplement (Vorschlag) | Wasser im Alltag (Vorschlag) |
| Wasser in der Küche | Meal Prep mit den fünf Wasserarten | Gutes Wasser für die ganze Familie |
| Flasche, Filter oder Gerät? | Dein Trinkplan für Trainingstage | Was steckt in deinem Wasser? |

**Persönlich, aber neutrales Cover (Jasmin 12.11.2026):** Das Cover zeigt nur Thema und Foto, keinen Partner. Seite 2:
kleines rundes Foto, "Empfohlen von", Name, Rolle und darunter "Warum ich dir das empfehle". Den Text schreibt der
Partner im Portal (Feld unter Instagram, bis 700 Zeichen) oder übernimmt eine von vier Vorlagen. Leer: Vorschlag passend
zum Thema (`BRIEFE` in `ebooks/inhalt.mjs`). Gespeichert in `uk_partner_seiten.brief`.

**Aufbau jedes E-Books (Lead-Magnet mit Brücke zum Gerät):** Titelseite, "Empfohlen von" mit Foto und Kontakt,
fünf Kapitel (Alltag, Wissen, Lösung Gerät, Praxis, Checkliste), am Ende jedes Kapitels ein Kasten mit Link zurück auf
die Seite, dann "So geht es weiter" mit QR-Code und Link zur Seite des Partners, hinten der rechtliche Hinweis.

**Look:** Ein Sport-E-Book kommt im Look der Sportseite des Partners (Hell oder Dunkel, Akzent), ein Gesundheits-E-Book
im Look seiner Gesundheitsseite usw. Hat er diese Seite nicht, gilt der Look seiner ersten Seite.

**Wie es gebaut ist:**
- Texte an EINER Stelle: `ebooks/inhalt.mjs`. Gestaltung: `ebooks/vorlage.html`, `vorlage.css`, `vorlage.js`.
- `werkzeuge/ebooks-bauen.mjs` druckt daraus jedes Buch in jedem Look als PDF (Chromium) und vermisst die freien
  Felder (Name, Foto, Kontakt, QR-Code, Links) in eine `.json` daneben. Es meldet, wenn Text über eine Seite hinausläuft.
  Außerdem schreibt es `ausgabe/vorlagen/katalog.json` und `website/p/ebooks.js` (Katalog für Seiten und Portal).
- Beim Abruf füllt `partner-ebook` (Datei `fuellen.js`) die Felder mit pdf-lib. Kein Upload je Partner.
- Ansehen im Browser: `http://localhost:8791/ebooks/vorlage.html?buch=meal-prep&modus=hell&akzent=beere&felder`
  (`&felder` zeigt die freien Felder gestrichelt).

**Text ändern:** in `ebooks/inhalt.mjs`, dann im Ordner `werkzeuge`:
```bash
npm install
```
```bash
node ebooks-bauen.mjs --alle --proben
```
Danach den Ordner `ausgabe/vorlagen` neu in den Speicher laden (Schritt 2). Im Paket liegen nur die 9 Vorschlags-Looks
(alle 126 wären 70 MB). Fehlt ein Look im Speicher, nimmt die Funktion den Vorschlags-Look des Buches.

## Was wo liegt

```
baukasten/
  LIESMICH.md              diese Datei
  offene-fragen.md         was ich nicht entscheiden konnte
  bild-prompts.md          Prompts für fehlende Fotos, Liste der übernommenen Fotos
  ueberschriften.md        alle Überschriften und Knöpfe zum Abhaken (Jasmin)
  website/
    _redirects-ergaenzung.txt   Zeilen für website/_redirects (ganz oben)
    p/                     NEU, kommt so nach website/p/
      neutral.html sport.html gesundheit.html   die drei Seiten
      start.html             Startseite wasseristmehr.com, ohne Person
      seiten.css seiten.js                      Gestaltung und Ablauf für alle drei
      farben.js                                  Grundtöne und Akzente, eine Stelle für alle Editoren
      vorschau-daten.js                          Beispieldaten, nur lokal oder mit ?demo geladen
      bilder/                                    Fotos (verkleinert), sport-hero.jpg fehlt noch
      ebooks.js                                  E-Book-Katalog (erzeugt, nicht von Hand ändern)
      vorschau/ebook-*.pdf                       Beispiel-E-Books mit Max Muster, nur für die lokale Vorschau
    partner/               Partnerportal
      seiten.js seiten.css NEU: Ansicht "Meine Seiten"
      partner.js           geändert, alle Stellen mit "BAUKASTEN 11.11.2026" markiert
      index.html           geändert: seiten.css und seiten.js eingebunden
      partner.js.diff index.html.diff   dieselben Änderungen als Diff (gegen den Stand im Paket, partner.js?v=20261111d)
  dashboard-ergaenzung/
    app.js.diff            Feld "Anfragen über seine Seiten" im Partner-Dialog des Dashboards (gegen dashboard/app.js im Projekt)
  supabase/
    umbau-2026-11-11-baukasten.sql   darf mehrfach laufen
    functions/partner-anfragenbot/   NEU: Webhook des Anfragen-Bots (verbinden, trennen)
    functions/partner-lead/          geändert: bei "Partner kümmert sich selbst" keine Gruppenmeldung, sondern Nachricht
                                     über den Anfragen-Bot an den Partner; Zeile "Seite: sport"
                                     (index.ts komplett, index.ts.diff zeigt die drei Stellen)
    functions/partner-ebook/         index.ts und empfohlen.js (gemeinsamer Code mit der lokalen Probe)
    functions/partner-foto/          index.ts
    ebook-schriften/                 Jost und Inter als TTF, vorbereitet für pdf-lib
  vorschau/                nur für die lokale Vorschau, nicht hochladen
    server.py              Mini-Server mit den Weiterleitungen aus _redirects
    start.html portal.html Startseite der Vorschau, Nachbau des Portal-Rahmens
    farbwelten.html        alle Grundtöne und Akzente zum Durchklicken
    portal-stand-2026-11-11.css   unveränderte Kopie von partner/portal.css
    schriften/             Jost und Inter (liegen auf dem Server schon unter /schriften/)
  ebooks/                  Inhalt (inhalt.mjs) und Druckvorlage der 9 E-Books, dazu ein paar Fotos
  ausgabe/vorlagen/        fertige E-Book-Vorlagen (PDF und Lage der Felder) für den Speicher, plus katalog.json
  werkzeuge/ebooks-bauen.mjs  baut die E-Book-Vorlagen und die Beispiel-E-Books
```

## Ansehen (lokal, ohne Datenbank)

Im Ordner `baukasten`:

```bash
python3 vorschau/server.py
```

Dann `http://localhost:8791/` öffnen. Die Startseite von wasseristmehr.com liegt lokal unter
`http://localhost:8791/startseite`, die Partner wie online unter `http://localhost:8791/max-muster`. Dort sind alle Seiten, die drei Zustände im Portal und die Beispiel-E-Books
verlinkt. Am Handy-Format ansehen (375 px). In der Portal-Vorschau kannst du das Formular wirklich ausfüllen,
ein Foto zuschneiden und speichern. "Vorschau" zeigt danach deine Seite mit diesen Angaben (bleibt im Browser).

## Einspielen, in dieser Reihenfolge

0. **Domain wasseristmehr.com mit Netlify verbinden** (zuerst, sonst zeigen die Links der Partner ins Leere):
   - In Netlify bei der Website unter "Domain management" `wasseristmehr.com` als weitere Domain hinzufügen, dazu
     `www.wasseristmehr.com`. Netlify zeigt danach genau an, welche Einträge nötig sind.
   - Bei IONOS unter "Domains & SSL", Domain, "DNS": die Einträge eintragen, die Netlify anzeigt. Üblich sind ein
     A-Eintrag für `@` auf die IP von Netlify und ein CNAME für `www` auf `<name-der-website>.netlify.app`.
     Die DNS-Verwaltung bleibt bei IONOS (nicht zu Netlify umziehen), dann lassen sich später die Mail-Einträge dazutun.
   - Warten, bis Netlify das Zertifikat ausgestellt hat (HTTPS).
   - Die Zeilen in `_redirects-ergaenzung.txt` mit `https://wasseristmehr.com/...`: ohne www, Portal, Dashboard und
     Backoffice bleiben auf mein.ursprungskraft.net, `/` zeigt die Startseite, `/<adresse>` die Partner.
     **Bitte prüfen:** Regeln mit Domain vorne, die auf einen Pfad derselben Website umschreiben (Status 200), sind bei
     Netlify so vorgesehen, ich konnte es aber nicht ausprobieren. Klappt es nicht, ist der Ausweg eine kleine
     Netlify Edge Function, die für den Host wasseristmehr.com dieselben Pfade umschreibt.
   - Später für den E-Mail-Dienst: Absender zum Beispiel `hallo@wasseristmehr.com`. Der Dienst nennt drei Einträge
     (SPF, DKIM, DMARC), die kommen ebenfalls bei IONOS unter "DNS" dazu. Ein Postfach ist dafür nicht nötig.
1. **Datenbank:** `supabase/umbau-2026-11-11-baukasten.sql` im SQL-Editor ausführen. Legt die Tabellen
   `uk_partner_seiten`, `uk_partner_seiten_alt`, `uk_partner_seiten_paket`, die Funktionen, die Einstellung
   `seiten_basis` und die Speicher-Buckets `partner-seiten` (öffentlich, Fotos) und `partner-ebooks` (privat) an.
   Am Ende zeigt sie die Seiten von Daniel und Jasmin, falls es Partner mit Kürzel `daniel` und `jasmin` gibt.
2. **Speicher:** Die drei Dateien aus `supabase/ebook-schriften/` nach `partner-ebooks/schriften/` hochladen.
   Den Ordner `ausgabe/vorlagen/` (vorher am besten `node ebooks-bauen.mjs --alle` für alle Looks) nach
   `partner-ebooks/vorlagen/` hochladen, mit `katalog.json` direkt darin. Zum Beispiel mit der Supabase-Oberfläche
   oder `supabase storage cp -r ausgabe/vorlagen ss:///partner-ebooks/vorlagen --experimental`.
3. **Anfragen-Bot anlegen** (einmal):
   - Bei Telegram mit @BotFather einen neuen Bot anlegen, zum Beispiel "Ursprungskraft Anfragen". Den Namen, der auf
     `bot` endet, notieren, den Schlüssel (Token) kopieren.
   - Schlüssel in den Tresor: `select vault.create_secret('<TOKEN>', 'tg_token_anfragen', 'Anfragen-Bot für Partner');`
   - Namen eintragen: `update uk_einstellungen set wert = '<name_bot>' where name = 'anfragenbot_name';`
     Solange der Name fehlt, steht im Portal "wird gerade eingerichtet" statt des Knopfs.
   - Nach dem Deploy (Schritt 4) den Webhook setzen. Das Geheimnis steht im Tresor unter `tg_webhook_anfragenbot`:
     ```bash
     curl "https://api.telegram.org/bot<TOKEN>/setWebhook?url=https://XXX.supabase.co/functions/v1/partner-anfragenbot&secret_token=<GEHEIMNIS>"
     ```
4. **Edge Functions:**
   ```bash
   supabase functions deploy partner-lead
   ```
   ```bash
   supabase functions deploy partner-anfragenbot --no-verify-jwt
   ```
   ```bash
   supabase functions deploy partner-foto
   ```
   ```bash
   supabase functions deploy partner-ebook --no-verify-jwt
   ```
   `partner-ebook` ohne "Verify JWT", weil der E-Book-Link ohne Schlüssel im Browser aufgeht. Sie gibt nur heraus,
   was die Seite ohnehin zeigt. `partner-foto` und `partner-lead` mit "Verify JWT" wie bisher.
   `partner-lead` erst nach der SQL deployen (sie ruft die neuen Funktionen `uk_partner_lead_zustaendig` und
   `uk_anfragenbot_ziel`). `partner-anfragenbot` ohne "Verify JWT", weil Telegram keinen Schlüssel schickt, sie prüft
   stattdessen das Webhook-Geheimnis.
5. **Schlüssel eintragen:** `XXX` in `website/p/seiten.js` (Supabase-Adresse und öffentlicher Schlüssel, derselbe wie in
   `dashboard/daten.js`) und in `website/_redirects-ergaenzung.txt` (Projektkennung). `partner.js` hat sie schon.
6. **Website:** `website/p/` in die Website legen (ohne `vorschau/`, die PDFs dort sind nur für die lokale Vorschau),
   alle Zeilen aus `_redirects-ergaenzung.txt` **ganz oben** in `website/_redirects`, in derselben Reihenfolge (vor allem
   vor der Regel für die Empfehlungslinks `/:kurz` von ursprungskraft.net, falls es die gibt).
   Im Partnerportal `seiten.js` und `seiten.css` dazulegen, `partner.js` und `index.html` ersetzen. Hat sich
   `partner.js` seit dem Paket geändert, die Diffs nehmen oder die markierten Stellen von Hand übertragen.
7. **Dashboard:** die zwei Zeilen aus `dashboard-ergaenzung/app.js.diff` in `website/dashboard/app.js` übernehmen.
   Das Dashboard speichert die Spalte `leads_bei` dann von selbst mit.
8. **Ein Upload** für alles. Danach braucht kein Partner mehr einen Upload.
9. **Paket freischalten** (bis Stripe kommt), im SQL-Editor:
   ```sql
   select uk_seiten_paket_setzen('anna-beispiel', current_date + 31);
   ```
   Nur bestimmte Fassungen: `select uk_seiten_paket_setzen('anna-beispiel', current_date + 31, '{sport}');`
10. **Domain wechseln** (falls je nötig): neue Domain wie in Schritt 0 verbinden, dann
   `update uk_einstellungen set wert = 'https://neue-domain.de' where name = 'seiten_basis';` Kein Upload nötig.

## Prüfen, bevor es online geht

- [ ] `select uk_seite_oeffentlich('daniel-zuercher', 'neutral');` liefert Name und Fassung, aber **kein** Telefon und
      keine E-Mail, solange "zeigen" nicht angehakt ist.
- [ ] Mit dem öffentlichen Schlüssel lässt sich `uk_partner_seiten` nicht direkt lesen (REST-Abfrage auf die Tabelle
      liefert nichts oder einen Fehler). Nur die Funktionen geben etwas heraus.
- [ ] `https://wasseristmehr.com` zeigt die Startseite "Wasser ist mehr", ohne Person. Testanfrage dort kommt mit
      Herkunft `wasseristmehr` in die Gruppe "Leads". `https://www.wasseristmehr.com` leitet auf ohne www um.
- [ ] `wasseristmehr.com/daniel-zuercher` zeigt Daniels Hauptseite, `/daniel-zuercher/sport` seine Sportseite,
      `/daniel-zuercher/gesundheit` leitet auf seine Hauptseite um, `/gibt-es-nicht` zeigt "Diese Seite gibt es gerade nicht".
- [ ] Partner mit Hauptseite Sport: `wasseristmehr.com/<adresse>` zeigt die Sportseite, der Link bleibt kurz.
- [ ] Alte Form `wasseristmehr.com/p/daniel-zuercher/neutral` geht und zeigt danach `/daniel-zuercher` in der Adresszeile.
- [ ] `wasseristmehr.com/impressum.html` und `/datenschutz/` gehen (Dateien gehen vor), `/partner/` führt ins Portal.
- [ ] Testanfrage über eine Partnerseite: Zeile in `uk_partner_leads` mit `herkunft` = Kürzel des Partners,
      `antworten->>'fassung'` gesetzt, Meldung in der Gruppe "Leads".
- [ ] Anfragen-Bot: Im Portal "Telegram verbinden", in Telegram "Starten", Begrüßung kommt, im Portal steht
      "Verbunden". Testanfrage kommt als Nachricht mit WhatsApp-Knopf. /stop trennt.
- [ ] Partner auf "kümmert sich selbst" stellen, Testanfrage: keine Meldung in der Gruppe "Leads", die Anfrage steht
      bei ihm unter "Meine Seiten" mit Kontakt. Bei "Daniel und Jasmin" umgekehrt, und er sieht dort keine Kontakte.
- [ ] Im Portal: Formular speichern, Foto hochladen (landet in `partner-seiten/<partner_id>/`, das alte wird gelöscht),
      Adresse ändern (alter Link leitet weiter), Zahlen je Fassung stimmen.
- [ ] `wasseristmehr.com/<adresse>/sport/e-book` öffnet das E-Book, das die Sportseite anbietet, im Look der Sportseite: Titelseite
      "Empfohlen von", Seite 2 mit Foto und Kontakt, vorletzte Seite mit QR-Code (mit dem Handy scannen, führt zur Seite).
- [ ] `wasseristmehr.com/<adresse>/e-book/familie` öffnet ein bestimmtes E-Book aus der Bibliothek.
- [ ] `wasseristmehr.com/wasseristmehr/neutral/e-book` öffnet das E-Book der Startseite ("Warum wir dir das empfehlen").
- [ ] Im Portal: oben "Dein Link" mit `wasseristmehr.com/<adresse>`, bei mehreren Seiten "Als Hauptseite nehmen".
- [ ] Alle drei Seiten am Handy (375 px) ohne seitliches Scrollen, Formulare abschicken.
- [ ] Im Portal für eine Seite Aufbau, Hell und einen Akzent wählen, speichern: die echte Seite zeigt es, die anderen Seiten
      behalten ihren Vorschlag.
- [ ] Jasmin hat `ueberschriften.md` abgehakt und `offene-fragen.md` beantwortet.
- [ ] Datenschutzerklärung passt für Partnerseiten (siehe offene Frage 11).

## Was ich getestet habe

- SQL in einer lokalen Postgres 16 mit nachgebauten Supabase-Teilen (Rollen, Tresor, Speicher), zusammen mit
  `10-31b-partnerportal` und `11-06-partner-leads`: läuft fehlerfrei und zweimal hintereinander. Geprüft: Vorschlag der
  Adresse ("Änne Sophie Groß-Weiß" wird `aenne-sophie-gross-weiss`), Sperre ohne Paket, Prüfung der Adresse (vergeben,
  reserviert, Form), Speichern mit Instagram-Link, Umleitung auf vorhandene Fassung, Umbenennen mit Weiterleitung der
  alten Adresse, Telefon nur mit Freigabe, Zählung der Leads je Fassung, Rechte (anon kommt nicht an die Tabelle und
  nicht an die Foto-Funktionen).
- Seiten und Portal mit Playwright (Chromium) bei 1440 und 375 px: kein seitliches Scrollen, keine Fehler im Browser.
  Abläufe: Foto wählen und zuschneiden, Formular speichern, Live-Vorschau beim Tippen, Lead-Formular mit Prüfungen,
  E-Book-Formular, drei Rechner, unbekannte Adresse, Umleitung auf vorhandene Fassung.
- Farbwelten: SQL (Speichern, ungültige Werte werden verworfen, je Fassung an die Seite), Editor im Portal
  (Umschalten, Vorschau, Speichern, echte Seite zeigt die Wahl), alle sieben Akzente auf Hell und Dunkel als Bild geprüft.
- Das geänderte `partner.js` mit nachgebauten Portal-Daten: `#seiten`, `#seiten/info`, Tools und Mehr-Menü laufen.
- "Wer kümmert sich": SQL (Spalte, Prüfung auf erlaubte Werte, `uk_partner_lead_zustaendig`, Kontakte nur bei `partner`),
  Seiten ("Max meldet sich" und "Wir melden uns"), Portal mit Anfrageliste und mit Hinweis.
- E-Book: `empfohlen.js` mit pdf-lib unter Node, Ergebnis als Bild geprüft (Seite 2 der Beispiel-PDFs).
- E-Books: alle 9 Bücher in allen 14 Looks gebaut, kein Überlauf. Gefüllt mit Beispieldaten, QR-Code mit einem
  QR-Leser geprüft (führt auf die Seite). Im Portal E-Book je Seite umgestellt, die Seite zeigt es, der Link nach dem
  Eintragen öffnet das richtige PDF. SQL für die Auswahl getestet.
- Startseite und kurze Links (12.11.2026): SQL (Hauptseite wählen, ungültige Wahl abgelehnt, ohne Fassung kommt die
  Hauptseite, Startseiten-Eintrag, gesperrte Wörter, zweimal hintereinander). Lokal mit nachgebildeten Regeln:
  Startseite, `/max-muster` (Hauptseite Sport, Link bleibt kurz), `/max-muster/neutral`, fehlende Fassung leitet um,
  unbekannte Adresse, alte Form `/p/...`. Startseite bei 1440 und 375 px ohne seitliches Scrollen, keine Fehler.
  Portal: kurzer Link, Hauptseite umstellen, E-Book-Links in kurzer Form. E-Book der Startseite als Bild geprüft.
- **Nicht getestet:** die Regeln mit Domain bei Netlify (siehe Schritt 0), die drei Edge Functions unter Deno und Supabase, die Dashboard-Ergänzung im echten Dashboard (kein Zugang), die Weiterleitung an die
  Edge Function über Netlify, das echte Hochladen in den Speicher.

## Bewusst nicht gebaut

- Stripe (Schnittstelle steht, siehe Schritt 9).

## Hinweise für das Einspielen

- `uk_partner_lead_speichern` setzt `partner_id` nur, wenn der Partner `aktiv = true` hat. Sonst hängt der Lead
  trotzdem über `herkunft` (Kürzel) am Partner und wird überall gefunden. Bei der Freigabe trotzdem `aktiv` prüfen.
- Gefunden, nicht geändert: In `uk_partner_registrieren` (10-31b) ist `translate(..., 'äöüßéèàç ', 'aousseeac-')`
  um ein Zeichen verschoben. Folge: "é" wird "s", ein Leerzeichen "c" ("Anna Lena" ergibt "annaclena"). Die neuen Seiten
  bauen ihre Adresse selbst und richtig ("ä" wird "ae").
- Gestaltung (zweite Fassung, Jasmin 11.11.2026): `website/p/seiten.css` ist Kevins `partner/empfehlung.css`
  (Anthrazit, große Felder, Pillen-Knöpfe, Effekte) plus Ergänzungen am Ende. Akzent je Fassung: Sport Kupfer wie Kevin,
  Neutral Oliv, Gesundheit Salbeigrün. Ändert ihr `empfehlung.css`, den oberen Teil von `seiten.css` mitziehen.
- Das E-Book-Formular auf den Seiten hat einen Einwilligungs-Haken (bei Kevin fehlt er).
- `partner-ebook` baut die PDF bei jedem Abruf neu (Sekundenbruchteile, der Browser hält sie eine Stunde).
