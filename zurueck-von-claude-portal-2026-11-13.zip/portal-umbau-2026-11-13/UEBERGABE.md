# Übergabe: Partnerportal, fünf Umbauten (13.11.2026)

Gebaut nach `AUFTRAG.md` vom 13.11.2026. Nichts hochgeladen, nichts deployt, keine Datenbank geändert. Schlüssel stehen weiter als `XXX` drin.

## Was im Paket ist

| Ordner / Datei | Inhalt |
|---|---|
| `aenderungen/*.diff` | Nur die Änderungen an bestehenden Dateien, je Datei ein Diff gegen den Stand aus dem Paket (`git apply` im Ordner über `website/` und `supabase/`) |
| `neu/supabase/umbau-2026-11-13-portal-profilfoto-kundenkarte.sql` | Neue SQL-Datei, ganze Datei. Darf mehrfach laufen. **Teil B bitte an die echten Funktionen anpassen** (siehe unten) |
| `screenshots/` | Computer 1440 × 900 und Handy 375 breit (ganze Seite), jeweils Hell und Dunkel. Die Zahl vorn im Namen ist der Punkt aus dem Auftrag |
| `pruefung/` | `kontrast.txt` und `klicktest.txt` mit den Ergebnissen, dazu die Prüfskripte (Playwright, laufen gegen `vorschau-ohne-cache.py 8790 website`) |

Geänderte Dateien: `partner.js`, `portal.css`, `flyer-anpassen.js`, `index.html`, `backoffice.js`, `backoffice.css`, `vorschau.js`, `supabase/partner-foto/index.ts`.
Nicht geändert: `flyer.js`, `wissen.js`.
Die `?v=` in `index.html` sind hochgezählt (`…20261113c`), ebenso die Version von `backoffice.js` in `BO_SKRIPTE` in `partner.js`.

## Einspielen, Reihenfolge

1. SQL-Datei: Teil A läuft so, wie er ist. Teil B legt nur Spalten an (Tabellenname `uk_partner_kunden` angenommen, bitte prüfen) und beschreibt in Kommentaren, was in `uk_partner_kunden` und `uk_partner_kunde_speichern` dazukommt. Die beiden Funktionen lagen dem Paket nicht bei, deshalb habe ich sie nicht blind überschrieben.
2. Edge Function `partner-foto` neu deployen (Diff). Der bisherige Zweck (Foto der eigenen Seite) ist unverändert, neu ist nur `?wofuer=profil`.
3. Website-Dateien einspielen.
4. Wenn ihr `uk_partner_daten` ohnehin anfasst: `'foto', p.foto` dazunehmen. Dann spart sich das Portal den zweiten Aufruf `uk_partner_foto`.

## 1. Hell und Dunkel: fertig

- Umschalter mit drei Knöpfen **Hell, Dunkel, Wie mein Gerät**: in der Kopfleiste neben dem Namen (am Computer oben rechts, am Handy in der Leiste oben, nur Symbole mit Namen beim Darüberfahren) und im Konto unter „Darstellung“ mit Wort. Gemerkt auf dem Gerät (`localStorage` `uk-farbe`). „Wie mein Gerät“ wechselt mit, wenn das Handy abends auf Dunkel geht.
- Ein kleines Skript in `index.html` setzt die Farbe schon vor dem ersten Bild, damit beim Laden nichts aufblitzt. `theme-color` wechselt mit.
- **Ohne Wahl bleibt es Dunkel**, so wie heute (siehe Frage 1).
- Hell: Grund Creme `#F5F1E8`, Felder Weiß, Akzent Olivgrün `#4F5A35`, Schrift `#2A2C22`, leise Schrift `#5F6152`. Der eine Blickpunkt je Ansicht (nächster Termin, nächster Schritt, Verkaufsbühne, Meldung unten) ist in Hell Olive tief mit heller Schrift, in Dunkel wie bisher hell. So bleibt die Idee „ein Blickpunkt in der Gegenfarbe“ in beiden Modi.
- `portal.css`: Alle fest eingetragenen Farben außerhalb von Geräten und Fotos sind auf Variablen umgestellt (67 Stellen, dazu 25 in `backoffice.css`). Neue Variablen stehen oben in `:root` (Dunkel) und in `:root[data-farbe="hell"]`. Halbtransparente Tönungen laufen über `rgba(var(--glanz), …)`, das in Dunkel hell und in Hell dunkel tönt.
- Fest geblieben (gewollt, in beiden Modi gleich): Handy, Laptop, A4-Blatt und Eichentisch im Flyer-Editor, die Anleitungs-Handys im Einstieg, Schrift auf Fotos mit dunklem Schleier, QR-Code auf Weiß, die Vorschau der Landingpage, Auswahlrahmen auf dem Flyer.
- Kleine Bilder in Daten-Adressen (Pfeil im Auswahlfeld, Lupe, Haken) können keine Variablen lesen, dafür gibt es eine Hell-Fassung.
- Team-Bereich gilt mit: eigene Variablen für Board-Spalten, Karten, Marker, Kalender-Chips. Die Farben der Termin-Arten nehmen in Hell die kräftigen Töne vom Anfang.
- **Kontrast gemessen, nicht geschätzt** (`pruefung/kontrast.txt`): Ein Skript läuft durch 23 Ansichten (Partner und Team-Bereich) in beiden Modi und in beiden Breiten, liest für jeden sichtbaren Text und jedes Eingabefeld die echte Schrift- und Hintergrundfarbe (Transparenz verrechnet) und rechnet nach WCAG. Zusammen rund 4 400 Texte. Ergebnis im Endstand: **keine Stelle unter 4,5 zu 1**. Kleinster Wert Hell 4,63 zu 1, Dunkel 5,11 zu 1.
  - Dabei gefunden und behoben: Kürzel „J“ im Team-Board (helle Schrift auf Gold, 3,1 zu 1, war schon vorher so, jetzt 5,2 zu 1) und der Knopf „Liste“ im Team-Kalender in Hell (4,3, jetzt 5,1).
  - Den Schalter „Partner | Backoffice“ misst das Skript nicht mit, weil die farbige Pille dahinter ein eigenes Element ist. Von Hand gemessen: Hell Weiß auf `#4F5A35` = 7,4 zu 1, Dunkel `#1F2418` auf `#FBF9F4` = 15,1 zu 1.
- **Nebenbei gefunden und behoben (war in Dunkel schon so):** In der Kundenkarte war der Text in „Was als Nächstes?“ und „Wann melden?“ unsichtbar, helle Schrift auf hellem Feld. Die allgemeine Regel für Felder war stärker als die für den Blickpunkt.

## 2. Nichts springt, nichts lädt neu: fertig

Alle Stellen in `partner.js`, die nach dem Speichern `zeigen()` aufriefen oder die ganze Ansicht neu bauten, sind umgebaut:

- **Kundenkarte** (`karte`, `kundeMerken`, `listeStill`, `stehenLassen`): Stand, Kein Interesse, Nächster Schritt, Notiz, Wichtig, Kontaktdaten ändern. Nach dem Speichern wird nur die betroffene Stelle getauscht. Die Daten im Portal werden so nachgeführt, wie die Datenbank sie ablegt. Die Liste hinter der Karte wird still neu gezeichnet (sie ist dabei versteckt), Filter und Scrollposition der Liste bleiben. Offener Reiter bleibt. Das Feld, an dem man arbeitet, bleibt an derselben Stelle im Bild.
- Kontakt aus dem E-Book (`art: 'lead'`), der beim ersten Speichern eine neue Kunden-ID bekommt: Adresse wird still umgeschrieben (`replaceState`), kein neuer Aufbau.
- **Neuer Kunde**: kommt direkt in den Speicher, die Karte öffnet sich ohne neues Laden.
- **Termine** (`T.auffrischen`, `terminGeaendert`): Termin speichern und löschen füllen nur Kalender, Woche, Tag, Listen und „Vergangene“ neu. Kein Sprung nach oben. Nach dem Speichern wird die Terminliste frisch geholt (Name und Zeit wie in der Datenbank). Ein Termin aus der Kundenkarte frischt dort nur die Terminzeile auf.
- **Einführung schließen**: baut die Startseite nicht mehr neu, nimmt nur den Einrichtungs-Hinweis weg, wenn der Haken gesetzt ist.
- Tools (Abwicklung, Landingpage), Flyer und Konto haben schon vorher nur die Stelle geändert.
- **Team-Bereich** (`backoffice.js`, `zeichnen`; die Glocke rückt am Computer links neben den neuen Umschalter): Jedes Speichern, jeder Haken und jeder Filter frischt jetzt still auf. Scrollposition der Seite, des Boards und jeder Spalte, offene Aufklapper und das Feld mit dem Cursor bleiben, ohne Auftritt-Bewegung. Nur beim Wechsel des Reiters baut sich die Seite mit Bewegung auf (`zeichnen(true)`). Der Haken im Board wird sofort sichtbar gesetzt und bei einem Fehler zurückgenommen.

Getestet mit Klicktests (`pruefung/klicktest.txt`) am Computer und am Handy: Karte wird nicht neu gebaut, keine Liste neu geladen, Feld bleibt an derselben Stelle (auf den Pixel), Termin speichern ohne Sprung, Haken im Team-Board ohne Sprung, Board bleibt seitlich an seiner Stelle. Alle 34 Prüfungen grün, keine Fehler im Browser.

## 3. Kundenkarte wie ein CRM: fertig (Datenbank: bitte Teil B)

- Über die ganze Breite. **Links**: Schnellknöpfe (Anrufen, WhatsApp, neu E-Mail, Termin), **Kontaktdaten** (früher „Angaben“) mit Symbolen: Telefon, E-Mail, Adresse mit Route, **Geburtstag** (mit „Wird in 12 Tagen 48 Jahre alt“), Erreichbar, Interesse, Erster Kontakt, Zuletzt gesprochen. Leere Felder zeigen „Noch nicht eingetragen“. „Ändern“ öffnet das Blatt mit allen Feldern, neu: Straße, PLZ, Geburtstag. Darunter **Wichtig zu dieser Person** (feste Notiz, Knopf erst aktiv, wenn sich etwas ändert).
- **Rechts**: der nächste Schritt als Blickpunkt, darunter die Reiter **Verlauf**, **Käufe**, **Bestellung** mit Anzahl. Pfeiltasten wechseln die Reiter.
  - Verlauf: oben „Gesprochen am“ (heute vorbelegt) und „Was wurde besprochen?“, darunter alle Notizen, neu oben, zum Durchscrollen, als Zeitleiste bis zum ersten Kontakt.
  - Käufe: was der Kunde gekauft hat, mit Datum (aus den Bestellungen über den Link, sonst Gerät und Kaufdatum der Karte).
  - Bestellung: **vier Stationen** Bestellt, An den Hersteller raus, Unterwegs, Geliefert, mit Haken, Datum je Station und markierter aktueller Station. Am Handy untereinander, breit nebeneinander.
- Am Handy untereinander, in der Reihenfolge: Schnellknöpfe, nächster Schritt, Kontaktdaten, Wichtig, Reiter, Ablegen.
- Die Stufe bleibt draußen.
- Neue Felder, die das Portal mitschickt: `strasse`, `plz`, `geburtstag`, `wichtig` und bei Notizen optional `notiz_am`. `vorschau.js` kennt sie schon. Solange die Datenbank sie nicht speichert, gehen sie beim nächsten Laden verloren, sonst passiert nichts.
- Bestellstand: `uk_partner_bestellstand` darf zusätzlich `unterwegs` als Stand und `verschickt_am`, `unterwegs_am`, `da_am` liefern. Ohne diese Angaben bleiben Station und Datum einfach leer.

## 4. Eigenes Profilfoto: fertig (Datenbank: Teil A)

- Konto, Abschnitt „Dein Foto“: Foto wählen, im Kreis zuschneiden (ziehen mit Maus oder Finger, Zoom-Regler), speichern. „Foto entfernen“ mit Rückfrage.
- Angezeigt in der Kopfleiste (Computer neben dem Namen, Handy rechts in der Leiste, jeweils als Link ins Konto), im Team-Bereich genauso, und auf der Startseite neben der Begrüßung. Ohne Foto stehen die Initialen da. Nach dem Speichern wechseln alle Stellen sofort, ohne neuen Aufbau.
- Auf `partner-foto` aufgebaut, nichts Zweites daneben: gleicher Bucket `partner-seiten`, gleiche Anmeldung über `x-sitzung`, gleiche Prüfungen (nur JPEG, höchstens 2 MB, alter Stand wird gelöscht). Neu ist nur `?wofuer=profil` mit eigenen Datenbankfunktionen und Dateinamen `profil-<zeit>.jpg`. Das Portal schickt ein quadratisches JPEG mit 600 × 600 Pixeln.
- Jeder angemeldete Partner darf ein Profilfoto haben, unabhängig vom Paket „Meine Seiten“.

## 5. Flyer-Editor, Spalte neben dem Flyer: fertig

- Drei Reiter **Text, Schrift, Farben** statt einer langen Liste zum Scrollen (`flyer-anpassen.js`, Reiter werden aus den Abschnitten mit `data-tafel` gebaut, Pfeiltasten gehen auch).
- **Text**: oben „Welcher Text?“ mit allen Texten des Flyers als Knöpfe (der gewählte ist markiert), darunter Vorschlag und Textfeld, darunter die Werkzeuge **mit Namen**: Größe (− und +), Stil (Fett), Ausrichtung, Sichtbar (Ausblenden). Datum und Ort mit Knopf „Zu den Angaben“. Foto: Zoom und „Foto über die ganze Fläche“.
- **Schrift**: Schriftart, Schriftfarbe (für alle Texte oder nur den gewählten, die Überschrift sagt es), Lesbarkeit mit Schatten und Kontur samt Konturfarbe.
- **Farben**: Akzent, Fläche neben dem Foto. Hat das Format keine Fläche, steht dort ein kurzer Satz statt eines leeren Reiters.
- Unten eine feste Leiste: **Rückgängig** und **Zurück zur Vorlage** (ausgegraut, solange nichts verändert ist).
- Lesbarkeit: Überschriften 16 px in normaler Schrift statt 13 px Großbuchstaben, Beschriftungen 14 px, Felder 16 px, Knöpfe mindestens 44 px hoch, Farbpunkte 32 statt 26 px. Die Spalte ist mindestens 340 px breit (das Gerät rückt dafür etwas zusammen), nichts läuft mehr über den Rand.
- Doppelt auf einen Text tippen öffnet den Reiter Text mit dem Cursor im Feld. Einfaches Antippen wählt den Text und lässt den Reiter, wo er ist (wer gerade Farben einstellt, bleibt bei Farben).
- Alle Funktionen sind geblieben. Die Motivauswahl links ist unverändert.

## Regeln eingehalten

Keine Gedankenstriche in sichtbaren Texten, Du-Form, deutsche Wörter. Keine neuen Leuchtflecken, Glas-Pillen oder Mausschein (in Hell sind Leiste und Kopf deckend statt gläsern). Abstände 8, 13, 21, 34, Schriftgrößen 13, 16, 20, 26, 33. Keine Funktion weggenommen.

## Fragen an Jasmin

1. Soll das Portal beim ersten Öffnen dunkel bleiben wie bisher, oder soll es sich nach dem Handy richten? Heute ist es Dunkel, bis jemand umschaltet. Die Änderung ist ein Wort.
2. Unter „Käufe“ stehen nur Käufe über den Bestell-Link. Sollen Partner einen Kauf auch selbst eintragen können, zum Beispiel wenn jemand anders gekauft hat?
3. Für die Station „Unterwegs“ gibt es noch keine Angabe in der Datenbank. Wer soll das eintragen, Daniel im Team-Bereich?
4. Das Profilfoto und das Foto auf der eigenen Seite sind getrennt. Soll das Profilfoto automatisch auch auf der Seite stehen, wenn dort noch keins ist?
