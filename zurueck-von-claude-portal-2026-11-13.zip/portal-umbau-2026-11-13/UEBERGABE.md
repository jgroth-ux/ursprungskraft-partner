# Übergabe: Partnerportal, fünf Umbauten (13.11.2026)

Gebaut nach `AUFTRAG.md` vom 13.11.2026. Nichts hochgeladen, nichts deployt, keine Datenbank geändert. Schlüssel stehen weiter als `XXX` drin.

## Was im Paket ist

| Ordner / Datei | Inhalt |
|---|---|
| `aenderungen/*.diff` | Nur die Änderungen an bestehenden Dateien, je Datei ein Diff gegen den Stand aus dem Paket (`git apply` im Ordner über `website/` und `supabase/`) |
| `neu/supabase/umbau-2026-11-13-portal-profilfoto-kundenkarte.sql` | Neue SQL-Datei, ganze Datei. Darf mehrfach laufen. Teile A bis D. **Teil B bitte an die echten Funktionen anpassen** (siehe unten) |
| `neu/website/gemeinsam/empfohlen-foto.js` | Neue Datei: Foto bei „Empfohlen von“ auf allen Reflink-Seiten (Nachtrag, siehe unten) |
| `screenshots/` | Computer 1440 × 900 und Handy 375 breit (ganze Seite), jeweils Hell und Dunkel. Die Zahl vorn im Namen ist der Punkt aus dem Auftrag |
| `pruefung/` | `kontrast.txt` und `klicktest.txt` mit den Ergebnissen, dazu die Prüfskripte (Playwright, laufen gegen `vorschau-ohne-cache.py 8790 website`) |

Geänderte Dateien: `partner.js`, `portal.css`, `flyer-anpassen.js`, `index.html`, `backoffice.js`, `backoffice.css`, `vorschau.js`, `supabase/partner-foto/index.ts`.
Nicht geändert: `flyer.js`, `wissen.js`.
Die `?v=` in `index.html` sind hochgezählt (`…20261113c` bis `…f`), ebenso die Version von `backoffice.js` in `BO_SKRIPTE` in `partner.js`.

## Einspielen, Reihenfolge

1. SQL-Datei: Teil A läuft so, wie er ist. Teil B legt nur Spalten an (Tabellenname `uk_partner_kunden` angenommen, bitte prüfen) und beschreibt in Kommentaren, was in `uk_partner_kunden` und `uk_partner_kunde_speichern` dazukommt. Die beiden Funktionen lagen dem Paket nicht bei, deshalb habe ich sie nicht blind überschrieben.
2. Edge Function `partner-foto` neu deployen (Diff). Der bisherige Zweck (Foto der eigenen Seite) ist unverändert, neu ist nur `?wofuer=profil`.
3. Website-Dateien einspielen.
4. `gemeinsam/empfohlen-foto.js` auf **jeder Reflink-Seite** einbinden (Landingpage `wasser/`, Bestellseite `bestellen/`, eigene Seiten, E-Book):
   `<script src="../gemeinsam/empfohlen-foto.js?v=20261113" defer></script>`. Schlüssel `XXX` darin wie überall ersetzen.
5. Wenn ihr `uk_partner_daten` ohnehin anfasst: `'foto', p.foto` dazunehmen. Dann spart sich das Portal den zweiten Aufruf `uk_partner_foto`.

## 1. Hell und Dunkel: fertig

- Umschalter mit drei Knöpfen **Hell, Dunkel, Wie mein Gerät**: in der Kopfleiste neben dem Namen (am Computer oben rechts, am Handy in der Leiste oben, nur Symbole mit Namen beim Darüberfahren) und im Konto unter „Darstellung“ mit Wort. Gemerkt auf dem Gerät (`localStorage` `uk-farbe`). „Wie mein Gerät“ wechselt mit, wenn das Handy abends auf Dunkel geht.
- Ein kleines Skript in `index.html` setzt die Farbe schon vor dem ersten Bild, damit beim Laden nichts aufblitzt. `theme-color` wechselt mit.
- **Ohne eigene Wahl gilt „Wie mein Gerät“** (Jasmin): Ein hell eingestelltes Handy bekommt Hell, ein dunkel eingestelltes Dunkel.
- Hell: siehe Farbsystem unten (Creme, Weiß, Dunkelgrün, dazu Gletscherblau als laute Farbe). Der eine Blickpunkt je Ansicht (nächster Termin, nächster Schritt, Verkaufsbühne, Meldung unten) ist in Hell Olive tief mit heller Schrift, in Dunkel wie bisher hell. So bleibt die Idee „ein Blickpunkt in der Gegenfarbe“ in beiden Modi.
- `portal.css`: Alle fest eingetragenen Farben außerhalb von Geräten und Fotos sind auf Variablen umgestellt (67 Stellen, dazu 25 in `backoffice.css`). Neue Variablen stehen oben in `:root` (Dunkel) und in `:root[data-farbe="hell"]`. Halbtransparente Tönungen laufen über `rgba(var(--glanz), …)`, das in Dunkel hell und in Hell dunkel tönt.
- Fest geblieben (gewollt, in beiden Modi gleich): Handy, Laptop, A4-Blatt und Eichentisch im Flyer-Editor, die Anleitungs-Handys im Einstieg, Schrift auf Fotos mit dunklem Schleier, QR-Code auf Weiß, die Vorschau der Landingpage, Auswahlrahmen auf dem Flyer.
- Kleine Bilder in Daten-Adressen (Pfeil im Auswahlfeld, Lupe, Haken) können keine Variablen lesen, dafür gibt es eine Hell-Fassung.
- Team-Bereich gilt mit: eigene Variablen für Board-Spalten, Karten, Marker, Kalender-Chips. Die Farben der Termin-Arten nehmen in Hell die kräftigen Töne vom Anfang.
- **Kontrast gemessen, nicht geschätzt** (`pruefung/kontrast.txt`): Ein Skript läuft durch 23 Ansichten (Partner und Team-Bereich) in beiden Modi und in beiden Breiten, liest für jeden sichtbaren Text und jedes Eingabefeld die echte Schrift- und Hintergrundfarbe (Transparenz verrechnet) und rechnet nach WCAG. Zusammen rund 4 400 Texte. Ergebnis im Endstand: **keine Stelle unter 4,5 zu 1**. Kleinster Wert Hell 4,67 zu 1, Dunkel 5,11 zu 1 (gemessen nach dem Farbsystem mit Gletscherblau).
  - Dabei gefunden und behoben: Spalte „Eingang“ im Team-Board in Hell aufgehellt (`#E8E1CF`), damit die graugrüne Schrift darauf 4,6 zu 1 hat. Außerdem: Kürzel „J“ im Team-Board (helle Schrift auf Gold, 3,1 zu 1, war schon vorher so, jetzt 5,2 zu 1) und der Knopf „Liste“ im Team-Kalender in Hell (4,3, jetzt 5,1).
  - Den Schalter „Partner | Backoffice“ misst das Skript nicht mit, weil die farbige Pille dahinter ein eigenes Element ist. Von Hand gemessen: Hell Weiß auf `#4F5A35` = 7,4 zu 1, Dunkel `#1F2418` auf `#FBF9F4` = 15,1 zu 1.
- **Nebenbei gefunden und behoben (war in Dunkel schon so):** In der Kundenkarte war der Text in „Was als Nächstes?“ und „Wann melden?“ unsichtbar, helle Schrift auf hellem Feld. Die allgemeine Regel für Felder war stärker als die für den Blickpunkt.

### Farbsystem Hell, von Jasmin festgelegt (13.11.2026)

Prinzip: **zwei ruhige Grundfarben, eine laute Farbe, die nur sparsam vorkommt.** Die laute Farbe ist aus den Grundfarben abgeleitet: Gegenfarbe zum warmen Creme, Richtung Wasser. Jasmin hat sie aus 16 Vorschlägen gewählt, weil sie den besten Kontrast zum Grün gibt.

| Rolle | Farbe | Variable | Wo |
|---|---|---|---|
| Grund | Creme `#F5F1E8` | `--c-ground` | Seite |
| Felder | Weiß `#FFFFFF` | `--c-surface` | Karten, Felder, Leiste unten |
| Schrift und Symbole | Dunkelgrün `#2C3A24` | `--c-ink` | Überschriften, Text, auch Schrift auf der lauten Farbe |
| Leise Schrift | Graugrün `#5A6650` | `--c-muted` | Beschriftungen, Nebensätze |
| Grün für Links, kleine Überschriften, Umschalter | `#3F5230` | `--c-olive`, `--c-khaki-light` | Links, Kicker, gewählte Reiter und Umschalter (weiße Schrift darauf) |
| Blickpunkt je Seite | Olive tief `#2F3524` | `--b-grund` | „Als Nächstes“, „Nächster Schritt“, Verkaufsbühne, Meldung unten |
| **Laut** | **Gletscherblau `#7FC4D8`**, darüber `#69B5CB` | `--laut`, `--laut-tief` | **nur**: Hauptknopf je Ansicht, gewähltes Symbol in der Leiste und im Kopf, Anruf-Knöpfe auf der Startseite, „heute“ in Kalender und Wochenbalken |
| Warnung | Rot `#A3402F` | `--rot` | Heute melden, Fälliges, Zähler |

Gemessen: Dunkelgrün auf Creme 10,7 zu 1, Dunkelgrün auf Gletscherblau 6,2 zu 1 (darüber 5,2), Weiß auf Grün `#3F5230` 8,5 zu 1, Graugrün auf Creme 5,4 zu 1.
Regel für später: Gletscherblau nie für Flächen, Texte oder Schmuck, sonst verliert es seine Wirkung. Dunkel bleibt unverändert (dort ist Khaki die laute Farbe).

## 2. Nichts springt, nichts lädt neu: fertig

Alle Stellen in `partner.js`, die nach dem Speichern `zeigen()` aufriefen oder die ganze Ansicht neu bauten, sind umgebaut:

- **Kundenkarte** (`karte`, `kundeMerken`, `listeStill`, `stehenLassen`): Stand, Kein Interesse, Nächster Schritt, Notiz, Wichtig, Kontaktdaten ändern. Nach dem Speichern wird nur die betroffene Stelle getauscht. Die Daten im Portal werden so nachgeführt, wie die Datenbank sie ablegt. Die Liste hinter der Karte wird still neu gezeichnet (sie ist dabei versteckt), Filter und Scrollposition der Liste bleiben. Offener Reiter bleibt. Das Feld, an dem man arbeitet, bleibt an derselben Stelle im Bild.
- Kontakt aus dem E-Book (`art: 'lead'`), der beim ersten Speichern eine neue Kunden-ID bekommt: Adresse wird still umgeschrieben (`replaceState`), kein neuer Aufbau.
- **Neuer Kunde**: kommt direkt in den Speicher, die Karte öffnet sich ohne neues Laden.
- **Termine** (`T.auffrischen`, `terminGeaendert`): Termin speichern und löschen füllen nur Kalender, Woche, Tag, Listen und „Vergangene“ neu. Kein Sprung nach oben. Nach dem Speichern wird die Terminliste frisch geholt (Name und Zeit wie in der Datenbank). Ein Termin aus der Kundenkarte frischt dort nur die Terminzeile auf.
- **Einführung schließen**: baut die Startseite nicht mehr neu, nimmt nur den Einrichtungs-Hinweis weg, wenn der Haken gesetzt ist.
- Tools (Abwicklung, Landingpage), Flyer und Konto haben schon vorher nur die Stelle geändert.
- **Team-Bereich** (`backoffice.js`, `zeichnen`; die Glocke rückt am Computer links neben den neuen Umschalter): Jedes Speichern, jeder Haken und jeder Filter frischt jetzt still auf. Scrollposition der Seite, des Boards und jeder Spalte, offene Aufklapper und das Feld mit dem Cursor bleiben, ohne Auftritt-Bewegung. Nur beim Wechsel des Reiters baut sich die Seite mit Bewegung auf (`zeichnen(true)`). Der Haken im Board wird sofort sichtbar gesetzt und bei einem Fehler zurückgenommen.

Getestet mit Klicktests (`pruefung/klicktest.txt`) am Computer und am Handy: Karte wird nicht neu gebaut, keine Liste neu geladen, Feld bleibt an derselben Stelle (auf den Pixel), Termin speichern ohne Sprung, Haken im Team-Board ohne Sprung, Board bleibt seitlich an seiner Stelle. Alle 34 Prüfungen grün, keine Fehler im Browser.

## 3. Kundenkarte wie ein CRM: fertig (Datenbank: bitte Teil B)

- Über die ganze Breite. **Links**: Schnellknöpfe (Anrufen, WhatsApp, neu E-Mail, Termin), **Kontaktdaten** (früher „Angaben“) mit Symbolen: Telefon, E-Mail, Adresse mit Route, **Geburtstag** (mit „Wird in 12 Tagen 48 Jahre alt“), Erreichbar, Interesse, Erster Kontakt, Zuletzt gesprochen. Leere Felder zeigen „Noch nicht eingetragen“. „Ändern“ öffnet das Blatt mit allen Feldern, neu: Straße, PLZ, Geburtstag. Darunter **Wichtig zu dieser Person** (feste Notiz, Knopf erst aktiv, wenn sich etwas ändert).
- **Rechts**: der nächste Schritt als Blickpunkt, darunter die Reiter **Verlauf**, **Käufe**, **Bestellung** mit Anzahl. Pfeiltasten wechseln die Reiter.
  - Verlauf: oben „Gesprochen am“ (heute vorbelegt) und „Was wurde besprochen?“, darunter alle Notizen, neu oben, zum Durchscrollen, als Zeitleiste bis zum ersten Kontakt.
  - Käufe: was der Kunde gekauft hat, mit Datum (aus den Bestellungen über den Link, sonst Gerät und Kaufdatum der Karte).
  - Bestellung: die drei Stationen wie bisher (Bestellt, An den Hersteller raus, Geliefert), aber deutlich als **Stationen mit Kreis, Haken, Verbindungslinie und Datum** statt der dünnen Linien, die aktuelle Station markiert. Am Handy untereinander, breit nebeneinander. (Im Auftrag stand zusätzlich „unterwegs“. Jasmin: gemeint war nur die bessere Darstellung, kein neuer Schritt. Deshalb wieder drei.)
- Am Handy untereinander, in der Reihenfolge: Schnellknöpfe, nächster Schritt, Kontaktdaten, Wichtig, Reiter, Ablegen.
- Die Stufe bleibt draußen.
- Neue Felder, die das Portal mitschickt: `strasse`, `plz`, `geburtstag`, `wichtig` und bei Notizen optional `notiz_am`. `vorschau.js` kennt sie schon. Solange die Datenbank sie nicht speichert, gehen sie beim nächsten Laden verloren, sonst passiert nichts.
- Bestellstand: `uk_partner_bestellstand` darf zusätzlich `verschickt_am` liefern, dann steht auch bei der zweiten Station ein Datum. Ohne das Feld bleibt es leer.

## 4. Eigenes Profilfoto: fertig (Datenbank: Teil A)

- Konto, Abschnitt „Dein Foto“: Foto wählen, im Kreis zuschneiden (ziehen mit Maus oder Finger, Zoom-Regler), speichern. „Foto entfernen“ mit Rückfrage.
- Angezeigt in der Kopfleiste (Computer neben dem Namen, Handy rechts in der Leiste, jeweils als Link ins Konto), im Team-Bereich genauso, und auf der Startseite neben der Begrüßung. Ohne Foto stehen die Initialen da. Nach dem Speichern wechseln alle Stellen sofort, ohne neuen Aufbau.
- Auf `partner-foto` aufgebaut, nichts Zweites daneben: gleicher Bucket `partner-seiten`, gleiche Anmeldung über `x-sitzung`, gleiche Prüfungen (nur JPEG, höchstens 2 MB, alter Stand wird gelöscht). Neu ist nur `?wofuer=profil` mit eigenen Datenbankfunktionen und Dateinamen `profil-<zeit>.jpg`. Das Portal schickt ein quadratisches JPEG mit 600 × 600 Pixeln.
- Jeder angemeldete Partner darf ein Profilfoto haben, unabhängig vom Paket „Meine Seiten“.

## 5. Flyer-Editor, Spalte neben dem Flyer: fertig

- Drei Reiter **Text, Schrift, Farben** statt einer langen Liste zum Scrollen (`flyer-anpassen.js`, Reiter werden aus den Abschnitten mit `data-tafel` gebaut, Pfeiltasten gehen auch).
- **Text**: oben „Welcher Text?“ mit allen Texten des Flyers als Knöpfe (der gewählte ist markiert), darunter Vorschlag und Textfeld, darunter die Werkzeuge **mit Namen**: Größe (− und +), Stil (Fett), Ausrichtung, Sichtbar (Ausblenden). Datum und Ort mit Knopf „Zu den Angaben“. Foto: Zoom und „Foto über die ganze Fläche“.
- **Schrift**: Schriftart, Schriftfarbe (für alle Texte oder nur den gewählten, die Überschrift sagt es), Lesbarkeit mit Schatten und Kontur samt Konturfarbe.
- **Farben**: Akzent, Fläche neben dem Foto. Hat das Format keine Fläche, steht dort ein kurzer Satz statt eines leeren Reiters.
- Unten eine feste Leiste: **Rückgängig** und **Zurück zur Vorlage** (ausgegraut, solange nichts verändert ist).
- Lesbarkeit: Überschriften 16 px in normaler Schrift statt 13 px Großbuchstaben, Beschriftungen 14 px, Felder 16 px, Knöpfe mindestens 44 px hoch, Farbpunkte 32 statt 26 px. Die Spalte ist mindestens 340 px breit (das Gerät rückt dafür etwas zusammen), nichts läuft mehr über den Rand.
- Doppelt auf einen Text tippen öffnet den Reiter Text mit dem Cursor im Feld. Einfaches Antippen wählt den Text und lässt den Reiter, wo er ist (wer gerade Farben einstellt, bleibt bei Farben).
- Alle Funktionen sind geblieben. Die Motivauswahl links ist unverändert.

## Regeln eingehalten

Keine Gedankenstriche in sichtbaren Texten, Du-Form, deutsche Wörter. Keine neuen Leuchtflecken, Glas-Pillen oder Mausschein (in Hell sind Leiste und Kopf deckend statt gläsern). Abstände 8, 13, 21, 34, Schriftgrößen 13, 16, 20, 26, 33. Keine Funktion weggenommen.

## Nachtrag (13.11.2026, Antworten von Jasmin)

### Käufe selbst eintragen: fertig (Datenbank: Teil C)

Jasmin: „Ja, die Leute sollen es auch selber eintragen können. Später folgen Provisionsfelder und Berechnungen.“

- Kundenkarte, Reiter Käufe: Knopf **Kauf eintragen**. Im Blatt: was (LeveLuk K8, ANESPA DX, emGuarde GO, emGuarde Home oder „Etwas anderes“ mit eigenem Text), gekauft am (heute vorbelegt, nicht in der Zukunft), Notiz. Dazu der Haken **„Stand auf Gekauft setzen“**, vorausgewählt, wenn der Kunde noch nicht bei den Käufern steht.
- Selbst eingetragene Käufe stehen mit „selbst eingetragen“ in der Liste und lassen sich löschen (mit Rückfrage). Käufe über den Bestell-Link stehen mit „über deinen Link“ daneben, wie bisher nur zum Lesen.
- Speichern und Löschen ändern nur den Reiter Käufe und seine Zahl (Punkt 2 gilt auch hier).
- Neue Tabelle `uk_partner_kaeufe` mit den Funktionen `uk_partner_kaeufe`, `uk_partner_kauf_speichern`, `uk_partner_kauf_loeschen` (Teil C). Bewusst eigene Tabelle, damit **Preis, Provision und Berechnungen** später als Spalten dazukommen, ohne die Kundentabelle anzufassen. Die Prüfung „nur eigene Kunden“ nimmt `uk_partner_kunden.partner_id` an, bitte prüfen, ebenso den Fremdschlüssel auf `kunde_id`.
- Fehlt die Funktion noch, lädt das Portal trotzdem, es gibt dann eben noch keine eigenen Käufe.

### Foto bei „Empfohlen von“ auf allen Reflink-Seiten: fertig (Datenbank: Teil D)

Jasmin: „Nicht automatisch auf die eigene Seite, das müssen die extra hochladen. Aber auf allen Reflink-Seiten soll unten links neben ‚Empfohlen von‘ zusätzlich ein kleiner Kreis mit deren Foto stehen“ (Vorbild Zinzino).

- Neuer Baustein `website/gemeinsam/empfohlen-foto.js`, ohne Bibliothek. Er liest das Kürzel aus `?von=`, holt über `uk_partner_empfehler(p_kurz)` Name und Profilfoto (öffentlich, nur freigegebene Partner, nur diese zwei Angaben) und setzt den runden Kreis vor den Text in `#empfohlen-fest` (unten links), `#empfohlen` (im Abschnitt) und alles mit `data-empfohlen`.
- Die Seiten selbst (`landing.js`, `bestellen.js`) lagen mir nicht vor und sind **nicht geändert**. Der Baustein wartet, bis die Seite den Text geschrieben hat, und setzt den Kreis auch nach jedem neuen Schreiben wieder davor. Ohne Foto bleibt alles wie bisher.
- Getestet auf einer Kopie der Vorbild-Landingpage aus `wissenspaket/` (Screenshots `…-7-empfohlen-…`), am Computer und am Handy.
- Das Profilfoto erscheint damit an drei Stellen: Kopfleiste, Startseite, „Empfohlen von“. Auf der eigenen Seite (Paket „Meine Seiten“) bleibt es getrennt, wie Jasmin es will. Der Hinweis im Konto sagt das.

## Fragen an Jasmin

1. Erledigt: Ohne eigene Wahl gilt „Wie mein Gerät“.
2. Erledigt: Käufe lassen sich selbst eintragen (siehe Nachtrag).
3. Erledigt: „Unterwegs“ ist raus, es bleiben drei Stationen in der neuen Darstellung.
4. Erledigt: bleibt getrennt, dafür Foto bei „Empfohlen von“ (siehe Nachtrag).
