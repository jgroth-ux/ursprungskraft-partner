// Empfohlen von, mit Foto (13.11.2026, Jasmin, Vorbild Zinzino): Auf jeder Seite mit Reflink (?von=kürzel) steht neben
// "Empfohlen von ..." zusätzlich ein kleiner Kreis mit dem Foto des Partners. Das Foto lädt der Partner selbst im Portal hoch
// (Konto, "Dein Foto"). Ohne Foto bleibt alles, wie es war.
// Einbinden: <script src="../gemeinsam/empfohlen-foto.js?v=20261113" defer></script> auf jeder Reflink-Seite
// (Landingpage wasser/, Bestellseite bestellen/, eigene Seiten, E-Book). Braucht sonst nichts, keine Bibliothek.
// Sucht die Stellen #empfohlen-fest (unten links), #empfohlen und alles mit data-empfohlen. Die Seite darf deren Text
// jederzeit neu schreiben, der Kreis wird danach wieder davorgesetzt.
// Daten: uk_partner_empfehler(p_kurz) liefert { name, foto } eines freigegebenen Partners (SQL vom 13.11.2026, Teil D).
(function () {
  'use strict';
  const SUPABASE = 'https://ngcbmpuqcqbelfoelwby.supabase.co';
  const OEFFENTLICH = 'sb_publishable_XXX';
  const von = (new URLSearchParams(location.search).get('von') || '').trim().toLowerCase();
  if (!/^[a-z0-9-]{2,40}$/.test(von)) return;

  const stil = document.createElement('style');
  stil.textContent = `
    .empfohlen-fest.empfohlen-mit-foto { padding-left: 6px !important; }
    .empfohlen-foto { display: inline-block; vertical-align: middle; margin: -4px 10px -4px 0; width: 32px; height: 32px; border-radius: 50%; object-fit: cover; background: #ECE6D8; box-shadow: 0 0 0 2px #FFFFFF, 0 0 0 3px rgba(42, 44, 34, .14); }
    #empfohlen .empfohlen-foto, [data-empfohlen] .empfohlen-foto { width: 44px; height: 44px; margin: -6px 13px -6px 0; }
    @media (max-width: 420px) { .empfohlen-fest .empfohlen-foto { width: 28px; height: 28px; } }`;
  document.head.append(stil);

  let daten = null;
  const ziele = () => document.querySelectorAll('#empfohlen-fest, #empfohlen, [data-empfohlen]');
  function setzen(el) {
    if (!daten || !daten.foto) return;
    const da = el.querySelector(':scope > img.empfohlen-foto');
    if (da && da === el.firstElementChild && da.getAttribute('src') === daten.foto) return;
    if (da) da.remove();
    const img = new Image(); img.className = 'empfohlen-foto'; img.src = daten.foto; img.alt = daten.name ? 'Foto von ' + daten.name : ''; img.decoding = 'async';
    img.onerror = () => { img.remove(); el.classList.remove('empfohlen-mit-foto'); };
    el.prepend(img); el.classList.add('empfohlen-mit-foto');
  }
  const alleSetzen = () => ziele().forEach(setzen);
  // Die Seite füllt oder ändert den Text später: dann den Kreis wieder davorsetzen
  const waechter = new MutationObserver(() => { waechter.disconnect(); alleSetzen(); beobachten(); });
  const beobachten = () => { ziele().forEach((el) => waechter.observe(el, { childList: true })); waechter.observe(document.body, { childList: true }); };

  async function laden() {
    // Für Vorschau und Test: window.UkEmpfohlen = { name, foto } ersetzt die Abfrage
    if (window.UkEmpfohlen) return window.UkEmpfohlen;
    try {
      const r = await fetch(`${SUPABASE}/rest/v1/rpc/uk_partner_empfehler`, { method: 'POST', headers: { apikey: OEFFENTLICH, Authorization: 'Bearer ' + OEFFENTLICH, 'Content-Type': 'application/json' }, body: JSON.stringify({ p_kurz: von }) });
      return r.ok ? await r.json() : null;
    } catch { return null; }
  }
  const los = async () => { daten = await laden(); if (!daten || !daten.foto) return; alleSetzen(); beobachten(); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', los); else los();
})();
