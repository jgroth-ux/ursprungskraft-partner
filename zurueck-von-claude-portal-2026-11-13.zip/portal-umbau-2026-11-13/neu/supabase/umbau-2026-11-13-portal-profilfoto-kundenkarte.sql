-- 13.11.2026: Partnerportal, Profilfoto und Kundenkarte wie ein CRM. Darf mehrfach laufen. Nicht ausgeführt, bitte prüfen und einspielen.
--
-- Teil A (vollständig): eigenes Profilfoto
--   Spalte uk_partner.foto, dazu die beiden Funktionen, die die Edge Function partner-foto mit ?wofuer=profil aufruft,
--   und uk_partner_foto(p_sitzung), aus der das Portal das Foto liest.
--   Schöner wäre 'foto', p.foto direkt in uk_partner_daten. Das Portal nimmt das Feld, sobald es da ist, und fragt dann nicht mehr extra.
--
-- Teil B (bitte anpassen): neue Felder der Kundenkarte
--   Die Funktionen uk_partner_kunden und uk_partner_kunde_speichern lagen dem Paket nicht bei. Teil B legt deshalb nur die Spalten an
--   und beschreibt unten genau, was in den beiden Funktionen dazukommt. Den Tabellennamen bitte prüfen (Annahme: uk_partner_kunden).

-- ===================== Teil A: Profilfoto =====================
alter table uk_partner add column if not exists foto text;

-- Wohin das Foto gehört: jeder angemeldete Partner, kein Paket nötig. Antwort wie bei uk_partner_seiten_foto_ziel.
create or replace function uk_partner_profilfoto_ziel(p_sitzung text) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object('partner_id', p.id, 'foto_alt', p.foto)
  from uk_partner p where p.id = uk_partner_von_sitzung(p_sitzung)
$$;
create or replace function uk_partner_profilfoto_setzen(p_partner uuid, p_foto text) returns void
language sql volatile security definer set search_path = public as $$
  update uk_partner set foto = p_foto where id = p_partner
$$;
revoke all on function uk_partner_profilfoto_ziel(text), uk_partner_profilfoto_setzen(uuid, text) from public, anon, authenticated;
grant execute on function uk_partner_profilfoto_ziel(text), uk_partner_profilfoto_setzen(uuid, text) to service_role;

-- Das Portal liest das Foto (Adresse im öffentlichen Bucket partner-seiten oder null)
create or replace function uk_partner_foto(p_sitzung text) returns text
language sql stable security definer set search_path = public as $$
  select p.foto from uk_partner p where p.id = uk_partner_von_sitzung(p_sitzung)
$$;
revoke all on function uk_partner_foto(text) from public;
grant execute on function uk_partner_foto(text) to anon, authenticated;

-- ===================== Teil B: Kundenkarte =====================
-- Neue Spalten: Geburtstag, Straße, PLZ und "Wichtig zu dieser Person" (feste Notiz, bleibt stehen)
do $$
declare t text := 'uk_partner_kunden';   -- Tabellenname prüfen
begin
  if to_regclass(t) is null then raise notice 'Tabelle % fehlt, Teil B bitte von Hand anpassen', t; return; end if;
  execute format('alter table %I add column if not exists geburtstag date', t);
  execute format('alter table %I add column if not exists strasse text', t);
  execute format('alter table %I add column if not exists plz text', t);
  execute format('alter table %I add column if not exists wichtig text', t);
end $$;

-- In uk_partner_kunden (Liste für das Portal) je Kunde vier Felder mehr ausgeben:
--   'geburtstag', k.geburtstag, 'strasse', k.strasse, 'plz', k.plz, 'wichtig', k.wichtig
--
-- In uk_partner_kunde_speichern(p_sitzung, p jsonb) dieselben vier Felder übernehmen, genau wie heute ort oder erreichbar:
--   nur wenn der Schlüssel in p steht (p ? 'geburtstag'), leerer Text wird null. geburtstag als date: nullif(p->>'geburtstag', '')::date
--   wichtig auf 2000 Zeichen kürzen (uk_txt(p->>'wichtig', 2000)), strasse 120, plz 12.
--
-- Datum des Gesprächs im Verlauf: das Portal schickt zur Notiz optional p->>'notiz_am' (JJJJ-MM-TT), wenn das Gespräch nicht heute war.
--   Beim Anlegen der Notiz als Zeitpunkt nehmen: coalesce((nullif(p->>'notiz_am', '')::date + time '12:00'), now()), höchstens heute.
--   letzter_kontakt nur dann darauf setzen, wenn das Datum neuer ist als der bisherige Wert.
--
-- Bestellstand (uk_partner_bestellstand): die Karte zeigt die drei Stationen bestellt, verschickt, da jetzt als Stationen mit Datum.
--   Wenn vorhanden, gern zusätzlich 'verschickt_am' liefern (da_am gibt es schon). Ohne das Feld bleibt das Datum leer.


-- ===================== Teil C (Nachtrag 13.11.2026): Käufe selbst eintragen =====================
-- Jasmin: Partner sollen Käufe auch selbst eintragen können (zum Beispiel, wenn jemand ohne den Bestell-Link gekauft hat).
-- Eigene Tabelle, damit später Preis, Provision und Berechnungen dazukommen können, ohne die Kundentabelle anzufassen.
-- Käufe über den Bestell-Link kommen weiter aus uk_partner_bestellstand und stehen nicht in dieser Tabelle.
create table if not exists uk_partner_kaeufe (
  id         uuid primary key default gen_random_uuid(),
  partner_id uuid not null references uk_partner(id) on delete cascade,
  kunde_id   uuid not null,   -- Kunde des Partners. Fremdschlüssel bitte ergänzen, sobald der Tabellenname feststeht (Annahme uk_partner_kunden)
  was        text not null check (length(btrim(was)) between 1 and 120),
  am         date not null,
  notiz      text check (notiz is null or length(notiz) <= 300),
  erstellt   timestamptz not null default now()
  -- Später: preis numeric(10,2), provision numeric(10,2), provision_stand text ...
);
create index if not exists uk_partner_kaeufe_partner on uk_partner_kaeufe (partner_id, kunde_id);
alter table uk_partner_kaeufe enable row level security;   -- nur über die Funktionen unten

-- Alle eigenen Käufe des angemeldeten Partners, für die Kundenkarte
create or replace function uk_partner_kaeufe(p_sitzung text) returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object('id', k.id, 'kunde_id', k.kunde_id, 'was', k.was, 'am', k.am, 'notiz', k.notiz) order by k.am desc, k.erstellt desc), '[]'::jsonb)
  from uk_partner_kaeufe k where k.partner_id = uk_partner_von_sitzung(p_sitzung)
$$;

-- Kauf eintragen. p: { kunde_id, was, am (JJJJ-MM-TT), notiz }. Antwort: id oder null.
create or replace function uk_partner_kauf_speichern(p_sitzung text, p jsonb) returns uuid
language plpgsql security definer set search_path = public as $$
declare v uuid := uk_partner_von_sitzung(p_sitzung); v_id uuid; v_kunde uuid; v_am date;
begin
  if v is null then return null; end if;
  begin v_kunde := (p->>'kunde_id')::uuid; v_am := (p->>'am')::date; exception when others then return null; end;
  if v_kunde is null or v_am is null or v_am > current_date or coalesce(btrim(p->>'was'), '') = '' then return null; end if;
  -- Nur eigene Kunden. Tabellen- und Spaltenname bitte prüfen (Annahme uk_partner_kunden.partner_id).
  if to_regclass('uk_partner_kunden') is not null then
    execute 'select 1 from uk_partner_kunden where id = $1 and partner_id = $2' using v_kunde, v into v_id;
    if v_id is null then return null; end if;
  end if;
  insert into uk_partner_kaeufe (partner_id, kunde_id, was, am, notiz)
  values (v, v_kunde, left(btrim(p->>'was'), 120), v_am, nullif(left(btrim(coalesce(p->>'notiz', '')), 300), ''))
  returning id into v_id;
  return v_id;
end $$;

create or replace function uk_partner_kauf_loeschen(p_sitzung text, p_id uuid) returns boolean
language plpgsql security definer set search_path = public as $$
declare v uuid := uk_partner_von_sitzung(p_sitzung);
begin
  if v is null then return false; end if;
  delete from uk_partner_kaeufe where id = p_id and partner_id = v;
  return found;
end $$;
revoke all on function uk_partner_kaeufe(text), uk_partner_kauf_speichern(text, jsonb), uk_partner_kauf_loeschen(text, uuid) from public;
grant execute on function uk_partner_kaeufe(text), uk_partner_kauf_speichern(text, jsonb), uk_partner_kauf_loeschen(text, uuid) to anon, authenticated;

-- ===================== Teil D (Nachtrag 13.11.2026): Foto bei "Empfohlen von" =====================
-- Für website/gemeinsam/empfohlen-foto.js auf allen Reflink-Seiten. Öffentlich (ohne Anmeldung), liefert nur Name und Foto
-- eines freigegebenen Partners, beides steht ohnehin auf der Seite. Ohne Foto: foto ist null, die Seite bleibt wie bisher.
create or replace function uk_partner_empfehler(p_kurz text) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object('name', btrim(coalesce(p.vorname, '') || ' ' || coalesce(p.nachname, '')), 'foto', p.foto)
  from uk_partner p where p.kurz = lower(btrim(p_kurz)) and p.status = 'freigegeben' limit 1
$$;
revoke all on function uk_partner_empfehler(text) from public;
grant execute on function uk_partner_empfehler(text) to anon, authenticated;

select 'ok' as stand;
