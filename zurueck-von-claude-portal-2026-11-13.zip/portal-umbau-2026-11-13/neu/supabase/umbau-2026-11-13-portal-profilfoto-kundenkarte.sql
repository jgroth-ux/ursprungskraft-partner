-- 13.11.2026: Partnerportal, Profilfoto und Kundenkarte wie ein CRM. Darf mehrfach laufen. Nicht ausgeführt, bitte prüfen und einspielen.
--
-- Teil A (vollständig): eigenes Profilfoto
--   Spalte uk_partner.foto, dazu die beiden Funktionen, die die Edge Function partner-foto mit ?wofuer=profil aufruft,
--   und uk_partner_foto(p_sitzung), aus der das Portal das Foto liest.
--   Schöner wäre 'foto', p.foto direkt in uk_partner_daten. Das Portal nimmt das Feld, sobald es da ist, und fragt dann nicht mehr extra.
--
-- Teil B (bitte anpassen): neue Felder der Kundenkarte
--   Die Funktionen uk_partner_kunden und uk_partner_kunde_speichern lagen dem Paket nicht bei. Teil B legt deshalb nur die Spalten an
--   und beschreibt unten genau, was in den beiden Funktionen dazukommt. Den Tabellennamen bitte prüfen (Annahme: uk_partner_kunden).

-- ===================== Teil A: Profilfoto =====================
alter table uk_partner add column if not exists foto text;

-- Wohin das Foto gehört: jeder angemeldete Partner, kein Paket nötig. Antwort wie bei uk_partner_seiten_foto_ziel.
create or replace function uk_partner_profilfoto_ziel(p_sitzung text) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object('partner_id', p.id, 'foto_alt', p.foto)
  from uk_partner p where p.id = uk_partner_von_sitzung(p_sitzung)
$$;
create or replace function uk_partner_profilfoto_setzen(p_partner uuid, p_foto text) returns void
language sql volatile security definer set search_path = public as $$
  update uk_partner set foto = p_foto where id = p_partner
$$;
revoke all on function uk_partner_profilfoto_ziel(text), uk_partner_profilfoto_setzen(uuid, text) from public, anon, authenticated;
grant execute on function uk_partner_profilfoto_ziel(text), uk_partner_profilfoto_setzen(uuid, text) to service_role;

-- Das Portal liest das Foto (Adresse im öffentlichen Bucket partner-seiten oder null)
create or replace function uk_partner_foto(p_sitzung text) returns text
language sql stable security definer set search_path = public as $$
  select p.foto from uk_partner p where p.id = uk_partner_von_sitzung(p_sitzung)
$$;
revoke all on function uk_partner_foto(text) from public;
grant execute on function uk_partner_foto(text) to anon, authenticated;

-- ===================== Teil B: Kundenkarte =====================
-- Neue Spalten: Geburtstag, Straße, PLZ und "Wichtig zu dieser Person" (feste Notiz, bleibt stehen)
do $$
declare t text := 'uk_partner_kunden';   -- Tabellenname prüfen
begin
  if to_regclass(t) is null then raise notice 'Tabelle % fehlt, Teil B bitte von Hand anpassen', t; return; end if;
  execute format('alter table %I add column if not exists geburtstag date', t);
  execute format('alter table %I add column if not exists strasse text', t);
  execute format('alter table %I add column if not exists plz text', t);
  execute format('alter table %I add column if not exists wichtig text', t);
end $$;

-- In uk_partner_kunden (Liste für das Portal) je Kunde vier Felder mehr ausgeben:
--   'geburtstag', k.geburtstag, 'strasse', k.strasse, 'plz', k.plz, 'wichtig', k.wichtig
--
-- In uk_partner_kunde_speichern(p_sitzung, p jsonb) dieselben vier Felder übernehmen, genau wie heute ort oder erreichbar:
--   nur wenn der Schlüssel in p steht (p ? 'geburtstag'), leerer Text wird null. geburtstag als date: nullif(p->>'geburtstag', '')::date
--   wichtig auf 2000 Zeichen kürzen (uk_txt(p->>'wichtig', 2000)), strasse 120, plz 12.
--
-- Datum des Gesprächs im Verlauf: das Portal schickt zur Notiz optional p->>'notiz_am' (JJJJ-MM-TT), wenn das Gespräch nicht heute war.
--   Beim Anlegen der Notiz als Zeitpunkt nehmen: coalesce((nullif(p->>'notiz_am', '')::date + time '12:00'), now()), höchstens heute.
--   letzter_kontakt nur dann darauf setzen, wenn das Datum neuer ist als der bisherige Wert.
--
-- Bestellstand (uk_partner_bestellstand): die Karte zeigt jetzt vier Stationen bestellt, verschickt, unterwegs, da.
--   'unterwegs' gibt es heute noch nicht. Sobald es eine Quelle dafür gibt, als stand liefern, dazu wenn vorhanden
--   'verschickt_am', 'unterwegs_am', 'da_am' (Datum je Station). Ohne diese Felder bleibt die Station einfach leer.

select 'ok' as stand;
