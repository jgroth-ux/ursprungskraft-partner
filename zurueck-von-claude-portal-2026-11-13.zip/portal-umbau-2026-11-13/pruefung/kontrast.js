// WCAG-Kontrast: node kontrast.js "#vorder" "#hinter" [ "#grund unter halbtransparentem hinter" ]
const hex = (h) => { h = h.replace('#', ''); if (h.length === 3) h = [...h].map((c) => c + c).join(''); return [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16)); };
const farbe = (s, unter) => {
  const m = s.match(/rgba?\(([^)]+)\)/);
  if (!m) return hex(s);
  const [r, g, b, a = 1] = m[1].split(',').map(Number);
  const u = unter ? farbe(unter) : [255, 255, 255];
  return [r, g, b].map((x, i) => Math.round(x * a + u[i] * (1 - a)));
};
const lum = (c) => { const [r, g, b] = c.map((v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }); return 0.2126 * r + 0.7152 * g + 0.0722 * b; };
const kontrast = (a, b) => { const [x, y] = [lum(a), lum(b)].sort((p, q) => q - p); return (x + 0.05) / (y + 0.05); };
module.exports = { farbe, kontrast };
if (require.main === module) {
  const [v, h, u] = process.argv.slice(2);
  const hg = farbe(h, u);
  console.log(kontrast(farbe(v, hg.length ? '#' + hg.map((x) => x.toString(16).padStart(2, '0')).join('') : undefined), hg).toFixed(2));
}
