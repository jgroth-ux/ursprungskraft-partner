// Klicktest Punkt 2: nach dem Speichern bleibt die Scrollposition, die Karte wird nicht neu gebaut, keine Liste neu geladen
const { chromium } = require('playwright');
const ergebnis = [];
const pruefe = (name, ok, info = '') => ergebnis.push(`${ok ? 'OK  ' : 'FEHL'} ${name}${info ? '  (' + info + ')' : ''}`);
(async () => {
  const b = await chromium.launch();
  for (const breite of [1440, 375]) {
    const p = await b.newPage({ viewport: { width: breite, height: 800 } });
    const fehler = []; p.on('pageerror', (e) => fehler.push(e.message));
    p.on('dialog', (d) => d.accept());
    await p.goto('http://localhost:8790/partner/?vorschau=normal#kunden/k1', { waitUntil: 'networkidle' }); await p.waitForTimeout(1200);
    await p.evaluate(() => { document.querySelector('.kk').dataset.test = 'gleich'; window.__abrufe = {}; });
    const tafel = await p.$('[data-teil="reiter"]'); await tafel.scrollIntoViewIfNeeded(); await p.evaluate(() => window.scrollBy(0, 200));
    const y0 = await p.evaluate(() => Math.round(document.querySelector('.kk-reiterleiste').getBoundingClientRect().top));
    // 1 Stand ändern
    const tu = (js) => p.evaluate(js).then(() => p.waitForTimeout(500));
    await tu(() => { const s = document.querySelector('[data-stand]'); s.value = 'kontaktiert'; s.dispatchEvent(new Event('change')); });
    // 2 Notiz im Verlauf
    await tu(() => { const f = document.querySelector('[data-notiz]'); f.notiz.value = 'Testnotiz vom Klicktest'; f.requestSubmit(); });
    // 3 Nächster Schritt
    await tu(() => { const f = document.querySelector('#f-weiter'); f.verblieben.value = 'Ruft Montag zurück'; f.requestSubmit(); });
    // 4 Wichtig
    await tu(() => { const f = document.querySelector('[data-wichtig]'); f.wichtig.value = 'Mag keine langen Telefonate'; f.dispatchEvent(new Event('input')); f.requestSubmit(); });
    // 5 Reiter wechseln
    await tu(() => document.querySelector('[data-kr="kaeufe"]').click()); await tu(() => document.querySelector('[data-kr="verlauf"]').click());
    const r = await p.evaluate(() => ({ y: Math.round(document.querySelector('.kk-reiterleiste').getBoundingClientRect().top), gleich: document.querySelector('.kk')?.dataset.test === 'gleich', abrufe: window.__abrufe,
      notiz: document.querySelector('[data-verlauf] li p')?.textContent, jetzt: document.querySelector('[data-jetzt]')?.textContent, stand: document.querySelector('[data-stand]').value,
      liste: [...document.querySelectorAll('#k-liste .zeile-kunde')].find((x) => x.href.endsWith('k1'))?.textContent.includes('Kontaktiert') }));
    pruefe(`[${breite}px] Karte nicht neu gebaut`, r.gleich);
    pruefe(`[${breite}px] Reiter bleiben an derselben Stelle im Bild`, Math.abs(r.y - y0) < 2, `vorher ${y0}, nachher ${r.y}`);
    pruefe(`[${breite}px] keine Liste neu geladen`, !r.abrufe.uk_partner_kunden && !r.abrufe.uk_partner_daten, JSON.stringify(r.abrufe));
    pruefe(`[${breite}px] Notiz oben im Verlauf`, r.notiz === 'Testnotiz vom Klicktest');
    pruefe(`[${breite}px] Nächster Schritt oben aktualisiert`, r.jetzt === 'Ruft Montag zurück');
    pruefe(`[${breite}px] Liste dahinter kennt neuen Stand`, r.liste === true);
    // Kontaktdaten ändern über das Blatt
    await p.click('[data-aendern]'); await p.fill('dialog.blatt [name=geburtstag]', '1980-05-17'); await p.fill('dialog.blatt [name=strasse]', 'Neue Straße 3');
    await p.click('dialog.blatt button[type=submit][value=ok]'); await p.waitForTimeout(500);
    const r2 = await p.evaluate(() => ({ gleich: document.querySelector('.kk')?.dataset.test === 'gleich', kontakt: document.querySelector('[data-teil="kontakt"]').textContent }));
    pruefe(`[${breite}px] Kontaktdaten ohne Neuaufbau geändert`, r2.gleich && r2.kontakt.includes('Neue Straße 3') && r2.kontakt.includes('17.05.1980'));
    // Zurück zur Liste und wieder rein: kein Laden
    await p.evaluate(() => { location.hash = 'kunden'; }); await p.waitForTimeout(300); await p.evaluate(() => { location.hash = 'kunden/k1'; }); await p.waitForTimeout(400);
    const r3 = await p.evaluate(() => window.__abrufe);
    pruefe(`[${breite}px] Liste und Karte wechseln ohne Laden`, !r3.uk_partner_kunden, JSON.stringify(r3));
    // Termine: Termin anlegen und löschen, Seite bleibt
    await p.evaluate(() => { location.hash = 'termine'; }); await p.waitForTimeout(1200);
    await p.evaluate(() => { document.querySelector('#kal').dataset.test = 'gleich'; });
    await p.click('[data-neu]'); await p.evaluate(() => window.scrollTo(0, 400));
    const ty = await p.evaluate(() => window.scrollY); await p.fill('dialog.blatt [name=datum]', new Date(Date.now() + 2 * 864e5).toISOString().slice(0, 10)); await p.fill('dialog.blatt [name=uhrzeit]', '15:30');
    await p.evaluate(() => document.querySelector('dialog.blatt button[type=submit][value=ok]').click()); await p.waitForTimeout(700);
    const t1 = await p.evaluate(() => ({ y: window.scrollY, gleich: document.querySelector('#kal')?.dataset.test === 'gleich', n: document.querySelectorAll('.kal-chip, .kal-tagliste article').length }));
    pruefe(`[${breite}px] Termin gespeichert ohne Neuaufbau`, t1.gleich, `Einträge sichtbar ${t1.n}`);
    pruefe(`[${breite}px] Termin: Scrollposition bleibt`, Math.abs(t1.y - ty) < 2, `vorher ${ty}, nachher ${t1.y}`);
    pruefe(`[${breite}px] keine Fehler im Browser`, !fehler.length, fehler.join(' | '));
    await p.close();
  }
  // Team-Bereich: Haken im Board
  const p = await b.newPage({ viewport: { width: 1440, height: 800 } });
  const fehler = []; p.on('pageerror', (e) => fehler.push(e.message));
  await p.goto('http://localhost:8790/partner/?vorschau#bo/aufgaben', { waitUntil: 'networkidle' }); await p.waitForTimeout(2500);
  const da = await p.$('.board .karte:not(.auto) input');
  if (!da) pruefe('Team-Bereich: Board geladen', false, fehler.join(' | '));
  else {
    await p.evaluate(() => { window.scrollTo(0, 120); const b = document.querySelector('.board'); b.scrollLeft = 300; });
    const v = await p.evaluate(() => ({ y: window.scrollY, x: document.querySelector('.board').scrollLeft }));
    await p.evaluate(() => { [...document.querySelectorAll('.board .karte:not(.auto) input')].find((i) => i.getBoundingClientRect().left > 0)?.click(); });
    await p.waitForTimeout(1200);
    const n = await p.evaluate(() => ({ y: window.scrollY, x: document.querySelector('.board').scrollLeft, rein: document.querySelectorAll('#inhalt .rein').length }));
    pruefe('Team-Bereich: Haken, Seite bleibt stehen', Math.abs(n.y - v.y) < 2, `vorher ${v.y}, nachher ${n.y}`);
    pruefe('Team-Bereich: Haken, Board bleibt an seiner Stelle', Math.abs(n.x - v.x) < 2, `vorher ${v.x}, nachher ${n.x}`);
    pruefe('Team-Bereich: keine Auftritt-Bewegung', n.rein === 0);
    pruefe('Team-Bereich: keine Fehler im Browser', !fehler.length, fehler.join(' | '));
  }
  console.log(ergebnis.join('\n'));
  await b.close();
})();
