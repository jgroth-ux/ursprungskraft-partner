const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch();
  for (const w of [375, 1440]) {
    const p = await b.newPage({ viewport: { width: w, height: 800 } });
    await p.goto('http://localhost:8790/partner/?vorschau=normal#kunden/k1', { waitUntil: 'networkidle' }); await p.waitForTimeout(1200);
    for (const [name, sel, tun] of [
      ['Notiz speichern', '[data-notiz]', () => { const f = document.querySelector('[data-notiz]'); f.notiz.value = 'Neue Notiz'; f.requestSubmit(); }],
      ['Wichtig speichern', '[data-wichtig]', () => { const f = document.querySelector('[data-wichtig]'); f.wichtig.value = 'Etwas Wichtiges, das ziemlich lang ist und umbricht'; f.dispatchEvent(new Event('input')); f.requestSubmit(); }],
      ['Nächster Schritt', '#f-weiter', () => { const f = document.querySelector('#f-weiter'); f.verblieben.value = 'Kurz'; f.requestSubmit(); }],
      ['Stand ändern', '[data-stand]', () => { const s = document.querySelector('[data-stand]'); s.value = 'termin'; s.dispatchEvent(new Event('change')); }],
    ]) {
      await p.evaluate((s) => { const e = document.querySelector(s); window.scrollBy(0, e.getBoundingClientRect().top - 150); }, sel);
      const vor = await p.evaluate((s) => Math.round(document.querySelector(s).getBoundingClientRect().top), sel);
      await p.evaluate(tun); await p.waitForTimeout(500);
      const nach = await p.evaluate((s) => Math.round(document.querySelector(s).getBoundingClientRect().top), sel);
      console.log(`${Math.abs(vor - nach) < 2 ? 'OK  ' : 'FEHL'} [${w}px] ${name}: Feld steht vorher bei ${vor} px, nachher bei ${nach} px`);
    }
    await p.close();
  }
  await b.close();
})();
