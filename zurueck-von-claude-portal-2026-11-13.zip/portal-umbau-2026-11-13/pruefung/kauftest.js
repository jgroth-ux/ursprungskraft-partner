const { chromium } = require('playwright');
(async () => {
  const [ordner] = process.argv.slice(2);
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1440, height: 900 } });
  const fehler = []; p.on('pageerror', (e) => fehler.push(e.message)); p.on('dialog', (d) => d.accept());
  await p.addInitScript(() => localStorage.setItem('uk-farbe', 'hell'));
  await p.goto('http://localhost:8790/partner/?vorschau=normal#kunden/k6', { waitUntil: 'networkidle' }); await p.waitForTimeout(1200);
  await p.evaluate(() => { document.querySelector('.kk').dataset.test = '1'; document.querySelector('[data-kr=kaeufe]').click(); document.querySelector('[data-kauf-neu]').click(); });
  await p.waitForTimeout(400); await p.screenshot({ path: ordner + '/kauf-blatt.png' });
  await p.selectOption('dialog.blatt [name=auswahl]', 'emGuarde GO'); await p.click('dialog.blatt [value=ok]'); await p.waitForTimeout(800);
  const r = await p.evaluate(() => ({ gleich: document.querySelector('.kk')?.dataset.test === '1', n: document.querySelectorAll('#kt-kaeufe .kk-kaeufe li').length, stand: document.querySelector('[data-stand]').value, zahl: document.querySelector('[data-kr-zahl=kaeufe]').textContent }));
  await p.evaluate(() => window.scrollTo(0, 250)); await p.waitForTimeout(300); await p.screenshot({ path: ordner + '/kaeufe.png' });
  await p.evaluate(() => document.querySelector('[data-kauf-weg]').click()); await p.waitForTimeout(500);
  const r2 = await p.evaluate(() => document.querySelectorAll('#kt-kaeufe .kk-kaeufe li').length);
  console.log(JSON.stringify(r), 'nach Löschen:', r2, 'Fehler:', fehler.length ? fehler : 'keine');
  await b.close();
})();
