const { chromium } = require('playwright');
(async () => {
  const z = process.argv[2]; const b = await chromium.launch();
  for (const [g, w, h, f, k] of [['computer', 1440, 900, 'hell', 'k2'], ['computer', 1440, 900, 'dunkel', 'k5'], ['handy', 375, 812, 'hell', 'k2']]) {
    const p = await b.newPage({ viewport: { width: w, height: h } });
    await p.addInitScript((x) => localStorage.setItem('uk-farbe', x), f);
    await p.goto('http://localhost:8790/partner/?vorschau=normal#kunden/' + k, { waitUntil: 'networkidle' }); await p.waitForTimeout(1500);
    await p.addStyleTag({ content: '.menue nav, nav.leiste, .menue::after, .vorschau-band { display: none !important; }' }); await p.evaluate(() => { document.querySelector('[data-kr=bestellung]').click(); document.querySelector('.kk-reiter').scrollIntoView({ block: 'center' }); }); await p.waitForTimeout(400);
    await p.locator('.kk-reiter').screenshot({ path: `${z}/${g}-${f}-3-bestellstationen-${k}.png` });
    await p.close();
  }
  await b.close();
})();
