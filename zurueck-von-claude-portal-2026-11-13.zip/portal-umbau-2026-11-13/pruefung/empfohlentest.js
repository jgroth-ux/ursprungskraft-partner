const { chromium } = require('playwright');
(async () => {
  const [ordner] = process.argv.slice(2);
  const b = await chromium.launch();
  for (const [n, w, h] of [['computer', 1440, 900], ['handy', 375, 812]]) {
    const p = await b.newPage({ viewport: { width: w, height: h }, deviceScaleFactor: 2 });
    await p.goto('http://localhost:8790/test-empfohlen/?von=anna-beispiel', { waitUntil: 'networkidle' }); await p.waitForTimeout(1500);
    const r = await p.evaluate(() => [...document.querySelectorAll('.empfohlen-foto')].length);
    await p.screenshot({ path: `${ordner}/empfohlen-${n}.png`, clip: { x: 0, y: h - 110, width: Math.min(w, 520), height: 110 } });
    await p.evaluate(() => document.getElementById('empfohlen').scrollIntoView({ block: 'center' })); await p.waitForTimeout(500);
    const box = await p.locator('#empfohlen').boundingBox();
    await p.locator('#empfohlen').evaluate((e) => e.parentElement.style.outline = '0'); await p.locator('#empfohlen').locator('..').screenshot({ path: `${ordner}/empfohlen-${n}-abschnitt.png` });
    console.log(n, 'Fotos gesetzt:', r);
    await p.close();
  }
  await b.close();
})();
