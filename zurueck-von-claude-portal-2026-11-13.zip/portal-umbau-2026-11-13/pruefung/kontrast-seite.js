// Misst im Browser für jeden sichtbaren Text den Kontrast zur tatsächlichen Hintergrundfarbe (Vorfahren durchlaufen, Transparenz verrechnet).
// Aufruf: node kontrast-seite.js <url-teil> <hell|dunkel> [breite]  -> listet alles unter 4,5 (großer Text unter 3)
const { chromium } = require('playwright');
(async () => {
  const [teil, farbe, breite = '1440', vorher = ''] = process.argv.slice(2);
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: +breite, height: 900 } });
  await p.addInitScript((f) => { try { localStorage.setItem('uk-farbe', f); } catch {} }, farbe);
  await p.goto('http://localhost:8790/partner/' + teil, { waitUntil: 'networkidle' });
  await p.waitForTimeout(1800);
  if (vorher) { await p.evaluate(vorher); await p.waitForTimeout(900); }
  const erg = await p.evaluate(() => {
    const parse = (s) => { const m = s.match(/rgba?\(([^)]+)\)/); if (!m) return null; const v = m[1].split(/[ ,\/]+/).filter(Boolean).map(Number); return [v[0], v[1], v[2], v.length > 3 ? v[3] : 1]; };
    const lum = (c) => { const [r, g, bb] = c.slice(0, 3).map((v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }); return 0.2126 * r + 0.7152 * g + 0.0722 * bb; };
    const misch = (o, u) => [0, 1, 2].map((i) => o[i] * o[3] + u[i] * (1 - o[3])).concat(1);
    const grundVon = (el) => {
      const schichten = [];
      for (let x = el; x; x = x.parentElement) {
        const st = getComputedStyle(x);
        if (st.backgroundImage !== 'none' && !/gradient/.test(st.backgroundImage)) return null; // Foto: nicht messbar
        if (/gradient/.test(st.backgroundImage)) return null;
        const c = parse(st.backgroundColor); if (c && c[3] > 0) { schichten.push(c); if (c[3] >= 1) break; }
        if (x.tagName === 'DIALOG' && x.open) {}
      }
      let u = [255, 255, 255, 1];
      for (const s of schichten.reverse()) u = misch(s, u);
      return u;
    };
    const aus = [], gemessen = [];
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    const gesehen = new Set();
    while (w.nextNode()) {
      const t = w.currentNode; if (!t.textContent.trim()) continue;
      const el = t.parentElement; if (gesehen.has(el)) continue; gesehen.add(el);
      const r = el.getBoundingClientRect(); if (!r.width || !r.height) continue;
      const st = getComputedStyle(el); if (st.visibility === 'hidden' || +st.opacity === 0) continue;
      if (el.closest('.schalter, .mk, .geraet, .lp-handy, .verkauf-handy, .buehne, .f-bild, .meldung-tg, canvas, .fe-tipp, [aria-hidden=true], .vorschau-band, option')) continue;
      let o = 1; for (let x = el; x; x = x.parentElement) o *= +getComputedStyle(x).opacity; if (o < 0.95) continue;
      const g = grundVon(el); if (!g) continue;
      const fc = parse(st.color); const f = misch(fc, g);
      const [a, bb] = [lum(f), lum(g)].sort((x, y) => y - x); const k = (a + 0.05) / (bb + 0.05);
      const gross = parseFloat(st.fontSize) >= 24 || (parseFloat(st.fontSize) >= 18.66 && +st.fontWeight >= 600);
      gemessen.push(k);
      if (k < (gross ? 3 : 4.5)) aus.push(`${k.toFixed(2)}  ${el.tagName.toLowerCase()}.${[...el.classList].join('.')}  "${t.textContent.trim().slice(0, 40)}"  ${st.color} auf rgb(${g.slice(0, 3).map(Math.round)})`);
    }
    // Eingabefelder: der eingetippte Text gegen den Feldgrund
    for (const el of document.querySelectorAll('input:not([type=checkbox]):not([type=radio]):not([type=range]):not([type=file]):not([hidden]), textarea, select')) {
      const r = el.getBoundingClientRect(); if (!r.width || el.closest('[hidden], .mk')) continue;
      const st = getComputedStyle(el), g = grundVon(el); if (!g) continue;
      const f = misch(parse(st.color), g); const [a, bb] = [lum(f), lum(g)].sort((x, y) => y - x); const k = (a + 0.05) / (bb + 0.05);
      gemessen.push(k); if (k < 4.5) aus.push(`${k.toFixed(2)}  Feld ${el.name || el.id}  ${st.color} auf rgb(${g.slice(0, 3).map(Math.round)})`);
    }
    aus.unshift(`gemessen: ${gemessen.length} Texte, kleinster Wert ${Math.min(...gemessen).toFixed(2)}`);
    return aus;
  });
  console.log(`== ${teil} (${farbe}, ${breite}px): ${erg.length - 1} Stellen unter dem Mindestkontrast, ${erg[0]}`); erg.shift();
  erg.forEach((x) => console.log('  ' + x));
  await b.close();
})();
